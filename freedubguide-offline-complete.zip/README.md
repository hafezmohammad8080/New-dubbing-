# FreeDubGuide

FreeDubGuide is an open-source, API-free dubbing helper. It runs as a static
React/Vite app and does not require an account, API key, database, backend, or
cloud service.

## Features

- Local browser speech recognition (where supported by the browser)
- Local text-to-speech using the device's installed voices
- SRT subtitle editor/exporter
- Tool catalog with custom entries saved in `localStorage`
- Responsive Bengali interface

## Run anywhere

Requires only Node.js 18+:

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
npm run preview
```

The app itself makes no API requests. Speech recognition and available voices
depend on the browser/device; the app clearly reports when a browser does not
support a capability.