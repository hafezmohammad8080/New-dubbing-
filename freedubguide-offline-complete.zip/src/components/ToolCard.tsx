import React from 'react';
import { Tool } from '../data';
import { ExternalLink } from 'lucide-react';

export default function ToolCard({ tool }: { tool: Tool }) {
  return (
    <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm hover:border-slate-600 transition-colors flex flex-col h-full">
      <div className="flex-grow">
        <h3 className="text-lg font-semibold text-white mb-2">{tool.name}</h3>
        <p className="text-slate-400 text-sm mb-4 leading-relaxed">{tool.description}</p>
        <div className="flex flex-wrap gap-2 mb-6">
          {tool.badges.map((badge, idx) => (
            <span 
              key={idx} 
              className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-700 text-slate-300 border border-slate-600"
            >
              {badge}
            </span>
          ))}
        </div>
      </div>
      <a
        href={tool.url}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center justify-center w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2.5 px-4 rounded-lg transition-colors group"
      >
        টুল খুলুন
        <ExternalLink className="ml-2 w-4 h-4 opacity-70 group-hover:opacity-100 transition-opacity" />
      </a>
    </div>
  );
}
