import React from 'react';
import { Mic, Type, Volume2, BookOpen } from 'lucide-react';

export default function Home({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="px-4 py-8 md:py-16 text-center max-w-2xl mx-auto space-y-10">
      <div className="space-y-4">
        <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white">
          ফ্রি ম্যানুয়াল ডাবিং গাইড
        </h2>
        <p className="text-lg text-slate-400 leading-relaxed max-w-xl mx-auto">
          মোবাইল বা পিসি দিয়ে সম্পূর্ণ ফ্রিতে ভিডিও ডাবিং করার সব সেরা টুল এবং গাইডলাইন এক জায়গায়।
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          onClick={() => onNavigate('stt')}
          className="flex flex-col items-center p-6 bg-slate-800 rounded-2xl border border-slate-700 hover:border-blue-500 hover:bg-slate-750 transition-all group"
        >
          <div className="w-14 h-14 bg-slate-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-blue-600/20 group-hover:text-blue-400 transition-colors">
            <Mic className="w-7 h-7 text-slate-300 group-hover:text-blue-400" />
          </div>
          <span className="font-semibold text-lg text-slate-200">অডিও → টেক্সট</span>
          <span className="text-sm text-slate-500 mt-1">ভয়েস থেকে সাবটাইটেল</span>
        </button>

        <button
          onClick={() => onNavigate('translate')}
          className="flex flex-col items-center p-6 bg-slate-800 rounded-2xl border border-slate-700 hover:border-emerald-500 hover:bg-slate-750 transition-all group"
        >
          <div className="w-14 h-14 bg-slate-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-emerald-600/20 group-hover:text-emerald-400 transition-colors">
            <Type className="w-7 h-7 text-slate-300 group-hover:text-emerald-400" />
          </div>
          <span className="font-semibold text-lg text-slate-200">অনুবাদ (Translate)</span>
          <span className="text-sm text-slate-500 mt-1">সাবটাইটেল রূপান্তর</span>
        </button>

        <button
          onClick={() => onNavigate('tts')}
          className="flex flex-col items-center p-6 bg-slate-800 rounded-2xl border border-slate-700 hover:border-purple-500 hover:bg-slate-750 transition-all group"
        >
          <div className="w-14 h-14 bg-slate-700 rounded-full flex items-center justify-center mb-4 group-hover:bg-purple-600/20 group-hover:text-purple-400 transition-colors">
            <Volume2 className="w-7 h-7 text-slate-300 group-hover:text-purple-400" />
          </div>
          <span className="font-semibold text-lg text-slate-200">টেক্সট → অডিও</span>
          <span className="text-sm text-slate-500 mt-1">ভয়েস জেনারেশন</span>
        </button>
      </div>
      
      <div className="pt-4">
        <button
          onClick={() => onNavigate('offline')}
          className="w-full mb-4 inline-flex items-center justify-center px-6 py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold transition-colors"
        >
          <Mic className="w-5 h-5 mr-2" />
          API ছাড়া লোকাল ডাবিং স্টুডিও খুলুন
        </button>
        <button
          onClick={() => onNavigate('guide')}
          className="inline-flex items-center justify-center px-6 py-3 border border-slate-600 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-medium transition-colors"
        >
          <BookOpen className="w-5 h-5 mr-2 text-slate-400" />
          সম্পূর্ণ ডাবিং গাইড পড়ুন
        </button>
      </div>
    </div>
  );
}
