import React from 'react';
import { BookOpen, AlertCircle, FileText, Smartphone, PlusCircle, Clock, Video, List, Mic2, ArrowLeft } from 'lucide-react';

export default function Guide({ onNavigate }: { onNavigate: (page: string) => void }) {
  return (
    <div className="px-4 py-6 max-w-3xl mx-auto space-y-8">
      <button 
        onClick={() => onNavigate('home')}
        className="flex items-center text-slate-400 hover:text-white mb-4 transition-colors"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        ফিরে যান
      </button>

      <div className="text-center sm:text-left flex flex-col sm:flex-row items-center gap-4 mb-8">
        <div className="w-16 h-16 bg-slate-800 rounded-2xl flex items-center justify-center shrink-0 border border-slate-700">
          <BookOpen className="w-8 h-8 text-slate-300" />
        </div>
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">সম্পূর্ণ গাইডলাইন (মোবাইল)</h2>
          <p className="text-slate-400">
            শুধু মোবাইল দিয়ে ফ্রি টুল ব্যবহার করে ১.৫-২ ঘণ্টার লং মুভি ডাবিং করার একদম বাস্তবসম্মত গাইড।
          </p>
        </div>
      </div>

      {/* Reality Check */}
      <div className="bg-slate-900 border border-amber-900/50 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <AlertCircle className="w-6 h-6 text-amber-400" />
          <h3 className="text-lg font-bold text-white">বাস্তব কথা (আগে পড়ুন)</h3>
        </div>
        <ul className="list-disc list-inside space-y-2 text-slate-300 text-sm leading-relaxed ml-2">
          <li>পুরো ১.৫–২ ঘণ্টার মুভি একসাথে ফ্রি টুলে প্রসেস করা প্রায় অসম্ভব।</li>
          <li>২–৫ মিনিট করে কাটলে ২০–৩০ ঘণ্টা লেগে যাবে — এটা করবেন না।</li>
          <li><strong>সবচেয়ে ভালো ব্যালান্স: ২০–৩০ মিনিট</strong> করে কাটা। একটা ২ ঘণ্টার মুভিতে প্রায় ৪–৬টা টুকরো হবে।</li>
          <li>পুরো মুভি না করে শুধু গুরুত্বপূর্ণ দৃশ্য বেছে নিলে অনেক সময় বাঁচবে।</li>
        </ul>
      </div>

      {/* Step 1 */}
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">১</div>
          <h3 className="text-xl font-bold text-white">মুভি কাটা (CapCut / VN)</h3>
        </div>
        <div className="space-y-3 text-slate-300 ml-11">
          <p className="flex items-start gap-2">
            <Video className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
            <span>মোবাইলে <strong>CapCut</strong> বা <strong>VN Video Editor</strong> খুলুন।</span>
          </p>
          <ul className="list-disc list-inside space-y-2 ml-7 text-slate-400">
            <li>পুরো মুভিটি ইমপোর্ট করুন।</li>
            <li>টাইমলাইনে গিয়ে <strong>২০-৩০ মিনিটের</strong> ছোট ছোট অংশে ভাগ করুন।</li>
            <li>প্রতিটি অংশ ৭২০p বা ১০৮০p রেজোলিউশনে এক্সপোর্ট করুন (সাইজ কম রাখতে)। অডিও আলাদা করতে চাইলে শুধু অডিও এক্সপোর্ট করুন।</li>
          </ul>
        </div>
      </div>

      {/* Step 2 */}
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center text-white font-bold text-sm">২</div>
          <h3 className="text-xl font-bold text-white">অডিও থেকে টেক্সট (STT)</h3>
        </div>
        <div className="space-y-3 text-slate-300 ml-11">
          <p className="flex items-start gap-2">
            <Mic2 className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
            <span>একটি ২০-৩০ মিনিটের টুকরো নিয়ে কাজ শুরু করুন।</span>
          </p>
          <ul className="list-disc list-inside space-y-2 text-slate-400">
            <li>এই সাইটের STT পেজ থেকে টুল (যেমন- Speakwise, free.ai, TurboScribe) বেছে নিন।</li>
            <li>সেটিংসে <strong>Speaker Diarization</strong> (পুরুষ/মহিলা আলাদা করা) এবং <strong>Timestamps</strong> চালু করুন।</li>
            <li>ডাউনলোড অপশন থেকে <strong>SRT ফরম্যাটে</strong> সাবটাইটেল ফাইলটি সেভ করুন।</li>
          </ul>
        </div>
      </div>

      {/* Step 3 */}
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">৩</div>
          <h3 className="text-xl font-bold text-white">অনুবাদ করা (Timestamp ঠিক রেখে)</h3>
        </div>
        <div className="space-y-3 text-slate-300 ml-11">
          <ul className="list-disc list-inside space-y-2 text-slate-400">
            <li>এই সাইটের Translate পেজ থেকে টুল (যেমন- CaptionX বা Musely SRT) খুলুন।</li>
            <li>ডাউনলোড করা ইংলিশ SRT ফাইলটি আপলোড করে বাংলা ভাষায় অনুবাদ করুন।</li>
            <li>খেয়াল রাখবেন যেন <strong>টাইমস্ট্যাম্প এবং স্পিকার লেবেল (যেমন SPK1:) নষ্ট না হয়</strong>। নতুন বাংলা SRT ফাইলটি ডাউনলোড করুন।</li>
          </ul>
        </div>
      </div>

      {/* Step 4 */}
      <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-amber-600 rounded-full flex items-center justify-center text-white font-bold text-sm">৪</div>
          <h3 className="text-xl font-bold text-white">ভয়েস তৈরি (TTS) এবং জোড়া দেওয়া</h3>
        </div>
        <div className="space-y-3 text-slate-300 ml-11">
          <ul className="list-disc list-inside space-y-2 text-slate-400">
            <li>বাংলা SRT থেকে <strong>পুরুষ স্পিকারের</strong> ডায়ালগগুলো আলাদা করে পুরুষ ভয়েস (TTS) বানান।</li>
            <li><strong>মহিলা স্পিকারের</strong> ডায়ালগগুলো আলাদা করে মহিলা ভয়েস দিয়ে অডিও বানান।</li>
            <li>CapCut বা VN অ্যাপে মূল ভিডিওটি নিন। ব্যাকগ্রাউন্ড মিউজিক আলাদা করুন বা ভলিউম কমিয়ে দিন।</li>
            <li>আপনার বানানো ভয়েসগুলো টাইমস্ট্যাম্প বা ঠোঁট নাড়া (lip-sync) অনুযায়ী টাইমলাইনে বসিয়ে দিন।</li>
          </ul>
        </div>
      </div>

      {/* Tips */}
      <div className="bg-slate-900 border border-blue-900/50 rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Clock className="w-6 h-6 text-blue-400" />
          <h3 className="text-lg font-bold text-white">সময় বাঁচানোর টিপস</h3>
        </div>
        <ul className="list-disc list-inside text-slate-400 ml-2 space-y-2 text-sm leading-relaxed">
          <li>পুরো মুভি না করে শুধু দরকারি দৃশ্য বেছে নিন।</li>
          <li>Speaker আলাদা করার দরকার না থাকলে তা বন্ধ রাখুন, কাজ অনেক দ্রুত হবে।</li>
          <li>Timestamp একদম ১০০% পারফেক্ট না হলেও ম্যানুয়ালি টেনে মিলিয়ে নেওয়া যায়।</li>
          <li>দৈনিক লিমিট আছে এমন টুল (যেমন- TurboScribe) একাধিক জিমেইল অ্যাকাউন্ট দিয়ে ব্যবহার করতে পারেন।</li>
          <li>পুরো ২ ঘণ্টার মুভি ডাবিং করতে ৪-৮ ঘণ্টা লাগতে পারে, তাই একটা টুকরো (২০ মিনিট) শেষ করে তবেই পরেরটায় যাবেন।</li>
        </ul>
      </div>

    </div>
  );
}
