import React from 'react';
import { Download, Mic, Pause, Play, Square, Type, Volume2 } from 'lucide-react';

type SpeechRecognitionResult = { [index: number]: { [index: number]: { transcript: string } } };
type SpeechRecognitionEvent = Event & { results: SpeechRecognitionResult };
type SpeechRecognitionInstance = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onend: (() => void) | null;
  onerror: (() => void) | null;
  start: () => void;
  stop: () => void;
};

const download = (name: string, content: string, type = 'text/plain') => {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
};

export default function OfflineStudio({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [tab, setTab] = React.useState<'stt' | 'tts' | 'srt'>('stt');
  const [text, setText] = React.useState('');
  const [language, setLanguage] = React.useState('bn-BD');
  const [listening, setListening] = React.useState(false);
  const [voices, setVoices] = React.useState<SpeechSynthesisVoice[]>([]);
  const [voice, setVoice] = React.useState('');
  const recognition = React.useRef<SpeechRecognitionInstance | null>(null);

  React.useEffect(() => {
    const loadVoices = () => {
      const available = window.speechSynthesis?.getVoices() ?? [];
      setVoices(available);
      if (!voice && available[0]) setVoice(available[0].name);
    };
    loadVoices();
    window.speechSynthesis?.addEventListener('voiceschanged', loadVoices);
    return () => window.speechSynthesis?.removeEventListener('voiceschanged', loadVoices);
  }, [voice]);

  const startListening = () => {
    const SpeechRecognition = (window as Window & { SpeechRecognition?: new () => SpeechRecognitionInstance; webkitSpeechRecognition?: new () => SpeechRecognitionInstance }).SpeechRecognition
      ?? (window as Window & { webkitSpeechRecognition?: new () => SpeechRecognitionInstance }).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('এই ব্রাউজারে লোকাল Speech Recognition নেই। Chrome/Edge-এর সাম্প্রতিক সংস্করণ ব্যবহার করুন।');
      return;
    }
    const instance = new SpeechRecognition();
    instance.lang = language;
    instance.continuous = true;
    instance.interimResults = true;
    instance.onresult = (event) => {
      let finalText = '';
      Object.keys(event.results).forEach((key) => {
        const result = event.results[Number(key)];
        if (result?.[0]?.transcript) finalText += result[0].transcript + ' ';
      });
      setText(finalText.trim());
    };
    instance.onend = () => setListening(false);
    instance.onerror = () => setListening(false);
    recognition.current = instance;
    instance.start();
    setListening(true);
  };

  const speak = () => {
    if (!text.trim() || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language;
    utterance.voice = voices.find((item) => item.name === voice) ?? null;
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="px-4 py-8 max-w-4xl mx-auto">
      <button onClick={() => onNavigate('home')} className="text-slate-400 hover:text-white mb-6">← ফিরে যান</button>
      <div className="mb-8">
        <p className="text-emerald-400 text-sm font-semibold mb-2">OFFLINE • NO API • NO ACCOUNT</p>
        <h2 className="text-3xl font-bold text-white">লোকাল ডাবিং স্টুডিও</h2>
        <p className="text-slate-400 mt-2">আপনার ব্রাউজার ও ডিভাইসের built-in capability ব্যবহার করে—কোনো API key বা cloud server ছাড়াই।</p>
      </div>
      <div className="flex flex-wrap gap-2 mb-6">
        {([['stt', 'অডিও → টেক্সট', Mic], ['tts', 'টেক্সট → ভয়েস', Volume2], ['srt', 'SRT এডিটর', Type]] as const).map(([id, label, Icon]) => (
          <button key={id} onClick={() => setTab(id)} className={`px-4 py-2 rounded-lg flex items-center gap-2 ${tab === id ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300'}`}>
            <Icon className="w-4 h-4" /> {label}
          </button>
        ))}
      </div>
      <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6">
        <div className="flex flex-wrap gap-3 mb-4">
          <select value={language} onChange={(e) => setLanguage(e.target.value)} className="bg-slate-900 text-white border border-slate-600 rounded-lg px-3 py-2">
            <option value="bn-BD">বাংলা</option><option value="en-US">English</option><option value="hi-IN">हिन्दी</option>
          </select>
          {tab === 'stt' && <button onClick={listening ? () => recognition.current?.stop() : startListening} className="bg-blue-600 text-white rounded-lg px-4 py-2 flex items-center gap-2">{listening ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}{listening ? 'রেকর্ড বন্ধ' : 'রেকর্ড শুরু'}</button>}
          {tab === 'tts' && <><select value={voice} onChange={(e) => setVoice(e.target.value)} className="bg-slate-900 text-white border border-slate-600 rounded-lg px-3 py-2 max-w-xs"><option value="">ডিফল্ট ভয়েস</option>{voices.map((item) => <option key={item.name} value={item.name}>{item.name}</option>)}</select><button onClick={speak} className="bg-purple-600 text-white rounded-lg px-4 py-2 flex items-center gap-2"><Play className="w-4 h-4" /> পড়ুন</button><button onClick={() => window.speechSynthesis?.pause()} className="bg-slate-700 text-white rounded-lg px-3 py-2"><Pause className="w-4 h-4" /></button><button onClick={() => window.speechSynthesis?.cancel()} className="bg-slate-700 text-white rounded-lg px-3 py-2"><Square className="w-4 h-4" /></button></>}
        </div>
        <textarea value={text} onChange={(e) => setText(e.target.value)} rows={14} placeholder={tab === 'stt' ? 'রেকর্ড শুরু করে কথা বলুন…' : tab === 'srt' ? 'এখানে SRT পেস্ট করুন…' : 'এখানে লেখাটি লিখুন…'} className="w-full bg-slate-950 border border-slate-700 rounded-xl p-4 text-slate-100 placeholder-slate-600 resize-y focus:outline-none focus:border-emerald-500" />
        <div className="flex justify-between items-center mt-4">
          <span className="text-sm text-slate-500">{text.length} অক্ষর • সব ডেটা এই ব্রাউজারেই থাকে</span>
          <button onClick={() => download(tab === 'srt' ? 'subtitle.srt' : 'transcript.txt', text, tab === 'srt' ? 'text/srt' : 'text/plain')} disabled={!text} className="bg-emerald-600 disabled:opacity-40 text-white rounded-lg px-4 py-2 flex items-center gap-2"><Download className="w-4 h-4" /> ডাউনলোড</button>
        </div>
      </div>
    </div>
  );
}