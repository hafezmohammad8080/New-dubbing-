import React, { useState, useEffect } from 'react';
import ToolCard from '../components/ToolCard';
import { sttTools, Tool } from '../data';
import { Mic, ArrowLeft, Plus, X } from 'lucide-react';

export default function STT({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [customTools, setCustomTools] = useState<Tool[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', description: '', url: '', badges: '' });

  useEffect(() => {
    const saved = localStorage.getItem('custom_stt');
    if (saved) {
      try { setCustomTools(JSON.parse(saved)); } catch (e) {}
    }
  }, []);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.url) return;
    
    const newTool: Tool = {
      id: 'custom-stt-' + Date.now(),
      name: formData.name,
      description: formData.description,
      url: formData.url,
      badges: formData.badges.split(',').map(b => b.trim()).filter(Boolean)
    };
    
    const updated = [...customTools, newTool];
    setCustomTools(updated);
    localStorage.setItem('custom_stt', JSON.stringify(updated));
    setFormData({ name: '', description: '', url: '', badges: '' });
    setShowForm(false);
  };

  const allTools = [...sttTools, ...customTools];

  return (
    <div className="px-4 py-6">
      <button 
        onClick={() => onNavigate('home')}
        className="flex items-center text-slate-400 hover:text-white mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        ফিরে যান
      </button>

      <div className="mb-10 text-center sm:text-left flex flex-col sm:flex-row items-center gap-4">
        <div className="w-16 h-16 bg-blue-900/50 rounded-2xl flex items-center justify-center shrink-0">
          <Mic className="w-8 h-8 text-blue-400" />
        </div>
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">অডিও থেকে টেক্সট (STT)</h2>
          <p className="text-slate-400 max-w-2xl">
            সম্পূর্ণ ওপেন-সোর্স, গিটহাব, এবং ১০০% ফ্রি এআই টুল। টাইমস্ট্যাম্প এবং স্পিকার আলাদা করার ফিচারগুলো দেখে বেছে নিন।
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
        {allTools.map(tool => (
          <ToolCard key={tool.id} tool={tool} />
        ))}
      </div>

      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 max-w-xl mx-auto">
        {!showForm ? (
          <button 
            onClick={() => setShowForm(true)}
            className="w-full flex items-center justify-center py-4 border-2 border-dashed border-slate-600 rounded-lg text-slate-400 hover:text-blue-400 hover:border-blue-400 transition-colors"
          >
            <Plus className="w-6 h-6 mr-2" />
            ম্যানুয়ালি নতুন টুল অ্যাড করুন
          </button>
        ) : (
          <form onSubmit={handleAdd} className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-white">নতুন টুল যোগ করুন</h3>
              <button type="button" onClick={() => setShowForm(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <input 
              type="text" required placeholder="টুলের নাম (যেমন: Whisper)" 
              value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input 
              type="url" required placeholder="লিংক (যেমন: https://...)" 
              value={formData.url} onChange={e => setFormData({...formData, url: e.target.value})}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input 
              type="text" placeholder="বর্ণনা (ছোট করে)" 
              value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input 
              type="text" placeholder="ব্যাজ (কমা দিয়ে লিখুন, যেমন: Free, Open Source)" 
              value={formData.badges} onChange={e => setFormData({...formData, badges: e.target.value})}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors">
              সেভ করুন
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
