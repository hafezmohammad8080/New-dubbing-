/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import Layout from './components/Layout';
import Home from './pages/Home';
import STT from './pages/STT';
import Translate from './pages/Translate';
import TTS from './pages/TTS';
import Guide from './pages/Guide';
import OfflineStudio from './pages/OfflineStudio';

export default function App() {
  const [activePage, setActivePage] = useState('home');

  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return <Home onNavigate={setActivePage} />;
      case 'stt':
        return <STT onNavigate={setActivePage} />;
      case 'translate':
        return <Translate onNavigate={setActivePage} />;
      case 'tts':
        return <TTS onNavigate={setActivePage} />;
      case 'guide':
        return <Guide onNavigate={setActivePage} />;
      case 'offline':
        return <OfflineStudio onNavigate={setActivePage} />;
      default:
        return <Home onNavigate={setActivePage} />;
    }
  };

  return (
    <Layout activePage={activePage} onNavigate={setActivePage}>
      {renderPage()}
    </Layout>
  );
}
