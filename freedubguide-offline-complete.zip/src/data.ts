export type Tool = {
  id: string;
  name: string;
  description: string;
  badges: string[];
  url: string;
};

export const sttTools: Tool[] = [
  { id: 'stt-1', name: 'TurboScribe', description: 'লং অডিও সাপোর্ট করে এবং টাইমস্ট্যাম্প ও স্পিকার (পুরুষ/মহিলা) আলাদা করে SRT দেয়।', badges: ['Timestamp', 'Speaker'], url: 'https://turboscribe.ai/' },
  { id: 'stt-2', name: 'Riverside Transcription', description: 'খুবই নিখুঁত ট্রান্সক্রিপশন। স্পিকার আইডেন্টিফিকেশন (SPK1, SPK2) সহ SRT দেয়।', badges: ['Speaker', 'Timestamp'], url: 'https://riverside.fm/transcription' },
  { id: 'stt-3', name: 'Notta.ai', description: 'অডিও আপলোড করলে টাইমস্ট্যাম্প সহ পুরুষ/মহিলা ডায়ালগ আলাদা করে দেয়।', badges: ['Speaker', 'Timestamp'], url: 'https://www.notta.ai/' },
  { id: 'stt-4', name: 'ScreenApp', description: 'ভিডিও/অডিও থেকে সাবটাইটেল তৈরি এবং স্পিকার আলাদা করার ওয়েব টুল।', badges: ['Speaker', 'Timestamp'], url: 'https://screenapp.io/' },
  { id: 'stt-5', name: 'Happy Scribe', description: 'পেশাদারদের জন্য দারুণ টুল। নিখুঁত টাইমস্ট্যাম্প ও স্পিকার লেবেল।', badges: ['Speaker', 'SRT Export'], url: 'https://www.happyscribe.com/' },
  { id: 'stt-6', name: 'Otter.ai', description: 'মিটিং বা লং অডিও থেকে স্পিকার আলাদা করতে অন্যতম সেরা টুল।', badges: ['Speaker', 'Timestamp'], url: 'https://otter.ai/' },
  { id: 'stt-7', name: 'Veed.io STT', description: 'ভিডিও আপলোড করলেই সাবটাইটেল তৈরি হয়, যা পরে SRT হিসেবে ডাউনলোড করা যায়।', badges: ['Video to SRT', 'Timestamp'], url: 'https://www.veed.io/tools/video-to-text' },
  { id: 'stt-8', name: 'Descript', description: 'অডিও এডিটিং ও স্পিকার আলাদা করার অন্যতম সেরা সফটওয়্যার (ওয়েবেও চলে)।', badges: ['Speaker', 'Timestamp'], url: 'https://www.descript.com/' },
  { id: 'stt-9', name: 'Fathom', description: 'ফ্রি রেকর্ডিং এবং স্পিকার ডায়ালগ আলাদা করার টুল।', badges: ['Speaker', 'Timestamp'], url: 'https://fathom.video/' },
  { id: 'stt-10', name: 'Fireflies.ai', description: 'লম্বা অডিওর জন্য উপযুক্ত। স্পিকার ট্র্যাকিং অসাধারণ।', badges: ['Speaker', 'Timestamp'], url: 'https://fireflies.ai/' },
  { id: 'stt-11', name: 'AssemblyAI Playground', description: 'এপিআই প্লেগ্রাউন্ডে অডিও আপলোড করে ফ্রিতে স্পিকার আলাদা করার সুবিধা।', badges: ['Playground', 'Speaker'], url: 'https://www.assemblyai.com/playground' },
  { id: 'stt-12', name: 'Deepgram', description: 'বিশ্বের অন্যতম দ্রুত ট্রান্সক্রিপশন স্পিচ-টু-টেক্সট।', badges: ['Fastest', 'Timestamp'], url: 'https://deepgram.com/' },
  { id: 'stt-13', name: 'Cockatoo', description: 'সুপার ফাস্ট এবং নিখুঁত এআই ট্রান্সক্রিপশন, SRT এক্সপোর্ট।', badges: ['Fast', 'SRT Export'], url: 'https://www.cockatoo.com/' },
  { id: 'stt-14', name: 'Gladia.io', description: 'হুইস্পার এআই ভিত্তিক অত্যন্ত শক্তিশালী স্পিকার সেপারেশন।', badges: ['Whisper based', 'Speaker'], url: 'https://www.gladia.io/' },
  { id: 'stt-15', name: 'Speechify Transcription', description: 'স্পিচিফাই এর ট্রান্সক্রিপশন সার্ভিস, টাইমস্ট্যাম্প সহ।', badges: ['Timestamp', 'Speaker'], url: 'https://speechify.com/transcription/' },
  { id: 'stt-16', name: 'Sonix.ai', description: 'খুবই দ্রুত স্পিচ টু টেক্সট করে এবং স্পিকার আলাদা করতে পারে।', badges: ['Fast', 'Speaker'], url: 'https://sonix.ai/' },
  { id: 'stt-17', name: 'Rev.ai', description: 'নিখুঁত ট্রান্সক্রিপশন ইঞ্জিন, টাইমস্ট্যাম্প ও স্পিকার লেবেল দেয়।', badges: ['High Accuracy', 'Speaker'], url: 'https://www.rev.ai/' },
  { id: 'stt-18', name: 'Trint', description: 'প্রফেশনাল ট্রান্সক্রিপশন টুল, ভিডিও ডাবিংয়ের জন্য ভালো।', badges: ['Pro', 'Timestamp'], url: 'https://trint.com/' },
  { id: 'stt-19', name: 'Microsoft Word Online Transcribe', description: 'অনলাইন ওয়ার্ডে অডিও দিলে স্পিকার অনুযায়ী টাইমস্ট্যাম্প সহ ট্রান্সক্রাইব করে।', badges: ['Free', 'Speaker'], url: 'https://www.office.com/launch/word' },
  { id: 'stt-20', name: 'Free.ai Transcribe', description: 'সহজ এবং ফ্রি ট্রান্সক্রিপশন সাইট, SRT এক্সপোর্ট করা যায়।', badges: ['Free', 'SRT Export'], url: 'https://free.ai/transcribe' }
];

export const translateTools: Tool[] = [
  { id: 'tr-1', name: 'CaptionX Subtitle Translator', description: 'সেরা ফ্রি অনলাইন অনুবাদক। SRT আপলোড করলে টাইমস্ট্যাম্প ১০০% ঠিক রাখে।', badges: ['Timestamp Kept', 'Free'], url: 'https://captionx.app/' },
  { id: 'tr-2', name: 'Translate-Subtitles.com', description: 'সহজে SRT ফাইল আপলোড করুন, টাইমস্ট্যাম্প না ভেঙে স্পিকারসহ অনুবাদ হবে।', badges: ['Timestamp Kept', 'Online'], url: 'https://translate-subtitles.com/' },
  { id: 'tr-3', name: 'SubtitleTools', description: 'সিম্পল ওয়েবসাইট। SRT দিন, অনুবাদ করা SRT নিয়ে নিন। টাইমস্ট্যাম্প ভাঙে না।', badges: ['Timestamp Kept', 'No Signup'], url: 'https://subtitletools.com/translate-subtitles' },
  { id: 'tr-4', name: '1c7 Translate Subtitle (Web)', description: 'ব্রাউজারেই কাজ করে, ফাইল আপলোড করলে সেকেন্ডের মধ্যে অনুবাদ, কোড ভাঙে না।', badges: ['Web Tool', 'Timestamp Kept'], url: 'https://1c7.github.io/Translate-Subtitle-File/' },
  { id: 'tr-5', name: 'EditingTools.io', description: 'প্রফেশনালদের জন্য। সাবটাইটেলের কোনো কোড বা টাইম ভাঙে না।', badges: ['Pro Tool', 'Timestamp Kept'], url: 'https://editingtools.io/subtitles/' },
  { id: 'tr-6', name: 'Veed Subtitle Translator', description: 'পারফেক্ট সাবটাইটেল ট্রান্সলেটর। টাইমস্ট্যাম্প ও লেবেল ঠিক থাকে।', badges: ['Timestamp Kept', 'Clean UI'], url: 'https://www.veed.io/tools/subtitle-translator' },
  { id: 'tr-7', name: 'Happy Scribe Translator', description: 'পেশাদার অনুবাদ টুল, স্পিকারের নাম (যেমন: SPK1:) ঠিক রাখে।', badges: ['Speaker Kept', 'Timestamp Kept'], url: 'https://www.happyscribe.com/subtitle-translator' },
  { id: 'tr-8', name: 'Zeemo.ai', description: 'এআই ব্যবহার করে সাবটাইটেল অনুবাদ এবং সিংক করার ওয়েব টুল।', badges: ['AI Translation', 'Timestamp Kept'], url: 'https://zeemo.ai/' },
  { id: 'tr-9', name: 'Flixier Subtitle Translator', description: 'খুব দ্রুত ব্রাউজার থেকেই সাবটাইটেল অনুবাদ করা যায়।', badges: ['Fast', 'Timestamp Kept'], url: 'https://flixier.com/tools/subtitle-translator' },
  { id: 'tr-10', name: 'Kapwing Subtitles', description: 'অনলাইন ভিডিও এডিটর যার বিল্ট-ইন সাবটাইটেল অনুবাদক আছে।', badges: ['Timestamp Kept', 'Online'], url: 'https://www.kapwing.com/subtitles' },
  { id: 'tr-11', name: 'Checksub', description: 'নির্ভুল সাবটাইটেল অনুবাদ এবং ক্রিয়েশন প্ল্যাটফর্ম।', badges: ['Accurate', 'Timestamp Kept'], url: 'https://checksub.com/' },
  { id: 'tr-12', name: 'Maestra', description: 'এআই সাবটাইটেল ট্রান্সলেটর, স্পিকার লেবেল ঠিক রাখতে সক্ষম।', badges: ['Speaker Kept', 'Timestamp Kept'], url: 'https://maestra.ai/' },
  { id: 'tr-13', name: 'Sonix Translation', description: 'ট্রান্সক্রিপশনের পাশাপাশি এরা শক্তিশালী অনুবাদও দেয়।', badges: ['High Quality', 'Timestamp Kept'], url: 'https://sonix.ai/translation' },
  { id: 'tr-14', name: 'SubtitlesTranslator (En)', description: 'একসাথে অনেকগুলো সাবটাইটেল ব্যাচ অনুবাদ করা যায়।', badges: ['Batch', 'Timestamp Kept'], url: 'https://subtitlestranslator.com/en/' },
  { id: 'tr-15', name: 'Nova A.I.', description: 'ভিডিও অনুবাদ এবং সাবটাইটেল জেনারেট করার ওয়েব অ্যাপ।', badges: ['Timestamp Kept', 'Online'], url: 'https://wearenova.ai/video-editing-tools/translate-subtitles/' },
  { id: 'tr-16', name: 'FlexClip Translator', description: 'ফ্রি সাবটাইটেল অনুবাদক, স্ট্রাকচার ঠিক রাখে।', badges: ['Timestamp Kept', 'Free'], url: 'https://www.flexclip.com/tools/translate-subtitle.html' },
  { id: 'tr-17', name: 'Media.io Translator', description: 'ভিডিও ও সাবটাইটেল অনুবাদের জন্য দারুণ একটি এআই টুল।', badges: ['Timestamp Kept', 'Online'], url: 'https://www.media.io/subtitle-translator.html' },
  { id: 'tr-18', name: 'Typito Subtitle Translator', description: 'অনলাইনে সহজে সাবটাইটেল অনুবাদ এবং ভিডিওতে বসানোর টুল।', badges: ['Timestamp Kept', 'Web'], url: 'https://typito.com/tools/subtitle-translator' },
  { id: 'tr-19', name: 'Simplified Subtitles', description: 'সাবটাইটেল অনুবাদ এবং এডিটিংয়ের এআই প্ল্যাটফর্ম।', badges: ['Timestamp Kept', 'AI'], url: 'https://simplified.com/video-editor/subtitle-translator' },
  { id: 'tr-20', name: 'Clideo Translator', description: 'খুবই সহজ ইন্টারফেস, SRT দিলে অনুবাদ করে ফেরত দেয়।', badges: ['Timestamp Kept', 'Easy'], url: 'https://clideo.com/subtitle-translator' }
];

export const ttsTools: Tool[] = [
  { id: 'tts-1', name: 'TTSMaker', description: 'সম্পূর্ণ ফ্রি, সাইনআপ লাগে না। পুরুষ ও মহিলার অনেকগুলো বাংলা/ইংরেজি ভয়েস আছে।', badges: ['100% Free', 'Male/Female'], url: 'https://ttsmaker.com/' },
  { id: 'tts-2', name: 'Kokoro TTS (Web)', description: 'বর্তমানে সেরা ফ্রি টিটিএস মডেল। ওয়েবে সরাসরি টেক্সট পেস্ট করে অডিও নামানো যায়।', badges: ['Best Free Quality', 'Male/Female'], url: 'https://huggingface.co/spaces/hexgrad/Kokoro-TTS' },
  { id: 'tts-3', name: 'Clipchamp', description: 'মাইক্রোসফটের দারুণ সব পুরুষ ও মহিলা ভয়েস এখানে ফ্রিতে ব্যবহার করা যায়।', badges: ['Free Microsoft Voices', 'Male/Female'], url: 'https://clipchamp.com/en/features/ai-voice-over-generator/' },
  { id: 'tts-4', name: 'ElevenLabs', description: 'ফ্রি টিয়ারে বিশ্বের সেরা ন্যাচারাল এআই ভয়েস। পুরুষ ও মহিলা ভয়েসের বিশাল কালেকশন।', badges: ['Best Quality', 'Male/Female'], url: 'https://elevenlabs.io/' },
  { id: 'tts-5', name: 'Speechify', description: 'হাই-কোয়ালিটি ন্যাচারাল স্পিচ তৈরি করার জন্য দারুণ ওয়েব অ্যাপ।', badges: ['High Quality', 'Male/Female'], url: 'https://speechify.com/' },
  { id: 'tts-6', name: 'Murf.ai', description: 'স্টুডিও কোয়ালিটি ভয়েস। পুরুষ/মহিলা এবং বয়স অনুযায়ী ভয়েস আলাদা করা যায়।', badges: ['Studio Quality', 'Male/Female'], url: 'https://murf.ai/' },
  { id: 'tts-7', name: 'Play.ht', description: 'অসাধারণ ভয়েস ক্লোনিং এবং টেক্সট টু স্পিচ সুবিধা।', badges: ['Voice Cloning', 'Male/Female'], url: 'https://play.ht/' },
  { id: 'tts-8', name: 'Lovo.ai', description: 'ডাবিংয়ের জন্য বিশেষভাবে তৈরি, চরিত্র অনুযায়ী (পুরুষ/মহিলা) ভয়েস দেওয়া যায়।', badges: ['Dubbing Focus', 'Male/Female'], url: 'https://lovo.ai/' },
  { id: 'tts-9', name: 'WellSaid Labs', description: 'অত্যন্ত প্রফেশনাল লেভেলের ভয়েস জেনারেশন টুল।', badges: ['Professional', 'Male/Female'], url: 'https://wellsaidlabs.com/' },
  { id: 'tts-10', name: 'FreeTTS', description: 'গুগল টিটিএস ইঞ্জিন ব্যবহার করে ফ্রিতে অডিও বানানোর ওয়েবসাইট।', badges: ['Google Engine', 'Free'], url: 'https://freetts.com/' },
  { id: 'tts-11', name: 'TTSMP3', description: 'খুব দ্রুত টেক্সট থেকে এমপি৩ ডাউনলোড করার সহজ ওয়েব টুল।', badges: ['Fast MP3', 'Male/Female'], url: 'https://ttsmp3.com/' },
  { id: 'tts-12', name: 'Narakeet', description: 'স্ক্রিপ্ট থেকে ভিডিও বা অডিও বানানোর জন্য দুর্দান্ত টিটিএস।', badges: ['Video/Audio', 'Male/Female'], url: 'https://www.narakeet.com/' },
  { id: 'tts-13', name: 'Fliki.ai', description: 'টেক্সট দিলে ভয়েস এবং ভিডিও দুটিই বানিয়ে দেয় চমৎকারভাবে।', badges: ['Voice & Video', 'Male/Female'], url: 'https://fliki.ai/' },
  { id: 'tts-14', name: 'CapCut Web TTS', description: 'ক্যাপকাটের ওয়েব ভার্সনে অসাধারণ সব পুরুষ/মহিলা ভয়েস রয়েছে।', badges: ['App/Web', 'Male/Female'], url: 'https://www.capcut.com/' },
  { id: 'tts-15', name: 'NaturalReaders', description: 'ন্যাচারাল এবং মানুষের মতো পড়তে সক্ষম টিটিএস ওয়েব টুল।', badges: ['Natural Reading', 'Male/Female'], url: 'https://www.naturalreaders.com/' },
  { id: 'tts-16', name: 'Veed TTS', description: 'ব্রাউজার থেকেই সরাসরি টেক্সটকে ভয়েসওভারে রূপান্তর করুন।', badges: ['Online Voiceover', 'Male/Female'], url: 'https://www.veed.io/tools/text-to-speech-video' },
  { id: 'tts-17', name: 'Listnr', description: 'পডকাস্ট এবং ডাবিং ভয়েসের জন্য ভালো একটি জেনারেটর।', badges: ['Podcast Voice', 'Male/Female'], url: 'https://listnr.tech/' },
  { id: 'tts-18', name: 'MicMonster', description: 'অ্যাডভান্সড ভয়েস কন্ট্রোল এবং ইমোশন যুক্ত করার টুল।', badges: ['Emotion Control', 'Male/Female'], url: 'https://micmonster.com/' },
  { id: 'tts-19', name: 'Wideo TTS', description: 'সিম্পল এবং কাজের টেক্সট টু স্পিচ ওয়েবসাইট।', badges: ['Simple', 'Male/Female'], url: 'https://wideo.co/text-to-speech/' },
  { id: 'tts-20', name: 'Free.ai TTS', description: 'ফ্রি এআই ভয়েস জেনারেটর ওয়েবসাইট।', badges: ['Free', 'Male/Female'], url: 'https://free.ai/tts' }
];
