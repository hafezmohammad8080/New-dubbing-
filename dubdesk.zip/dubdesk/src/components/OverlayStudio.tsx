/**
 * Preview-only overlay UI.
 *
 * No manual sliders / no editing controls — all audio behaviour (dedupe,
 * buffer cleanup, 30ms ducking, export) lives in `useAudioEngine`.
 */
import { useEffect } from "react";

import { fmtTime } from "@/lib/audio";
import { useAudioEngine } from "@/hooks/useAudioEngine";

export type NonVerbalHint = { start: number; end: number; kind: string };

type Props = {
  /** Original recording (audio or video file) chosen in step 1. */
  originalFile: File | null;
  /** Rendered dub track, produced in step 4. */
  dubBlob: Blob | null;
  /** Non-verbal moments the AI spotted while analysing the audio. */
  hints: NonVerbalHint[];
};

export default function OverlayStudio({ originalFile, dubBlob, hints }: Props) {
  const {
    origBuffer,
    clips,
    activeCount,
    playingId,
    busy,
    note,
    mixUrl,
    ready,
    addClips,
    toggleClip,
    removeClip,
    detect,
    previewClip,
    previewMix,
    exportMix,
    clipDuration,
  } = useAudioEngine({ originalFile, dubBlob });

  // AI hints -> clips (deduplicated by unique id + timestamp range).
  useEffect(() => {
    if (!origBuffer || !hints.length) return;
    addClips(hints.map((h) => ({ start: h.start, end: h.end, label: h.kind })));
  }, [hints, origBuffer, addClips]);

  return (
    <section className="panel mt-6">
      <h2 className="text-lg font-semibold">৫. নন-ভার্বাল সাউন্ড রিটেনশন ও অটো-ডাকিং</h2>
      <p className="mt-1 text-xs text-muted-foreground">
        মূল অডিওর হাসি, কান্না বা চিৎকার শনাক্ত করে ডাব ট্র্যাকের একই টাইমস্ট্যাম্পে বসানো হয় — ওই
        সময়টুকুতে ডাব ভয়েস ১০০% মিউট (০% গেইন, ৩০ms র‍্যাম্প) থাকে, তাই ডাবল সাউন্ড হয় না। সবই
        ব্রাউজারেই।
      </p>

      {!originalFile && (
        <p className="mt-4 rounded-lg border border-dashed px-3 py-4 text-xs text-muted-foreground">
          প্রথমে ১ নম্বর ধাপে মূল ফাইল আপলোড করুন।
        </p>
      )}

      {originalFile && (
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={detect}
            disabled={!origBuffer || Boolean(busy)}
            className="rounded-md bg-primary px-3 py-2 text-xs font-medium text-primary-foreground disabled:opacity-50"
          >
            নন-ভার্বাল মুহূর্ত শনাক্ত করুন
          </button>
          <button
            type="button"
            onClick={() => void previewMix()}
            disabled={!ready || Boolean(busy) || activeCount === 0}
            className="rounded-md border px-3 py-2 text-xs font-medium disabled:opacity-50"
          >
            {playingId === "mix" ? "প্রিভিউ থামান" : "মিক্স প্রিভিউ"}
          </button>
          <button
            type="button"
            onClick={exportMix}
            disabled={!ready || Boolean(busy) || activeCount === 0}
            className="rounded-md border px-3 py-2 text-xs font-medium disabled:opacity-50"
          >
            এক্সপোর্ট (WAV)
          </button>
          {busy && <span className="text-xs text-muted-foreground">{busy}</span>}
        </div>
      )}

      {clips.length > 0 && (
        <ul className="mt-4 divide-y rounded-lg border">
          {clips.map((c) => (
            <li key={c.id} className="flex items-center gap-3 px-3 py-2">
              <button
                type="button"
                onClick={() => void previewClip(c)}
                aria-label={playingId === c.id ? "থামান" : "প্রিভিউ"}
                className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border text-xs"
              >
                {playingId === c.id ? "■" : "▶"}
              </button>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{c.label}</p>
                <p className="text-[11px] text-muted-foreground">
                  {fmtTime(c.start)} – {fmtTime(c.end)} · {clipDuration(c).toFixed(2)}s
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={c.enabled}
                onClick={() => toggleClip(c.id)}
                className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${
                  c.enabled ? "bg-primary" : "bg-muted"
                }`}
              >
                <span
                  className={`absolute top-0.5 h-4 w-4 rounded-full bg-background transition-all ${
                    c.enabled ? "left-[1.15rem]" : "left-0.5"
                  }`}
                />
              </button>
              <button
                type="button"
                onClick={() => removeClip(c.id)}
                aria-label="মুছুন"
                className="shrink-0 text-xs text-muted-foreground hover:text-destructive"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      )}

      {note && <p className="mt-3 text-xs text-muted-foreground">{note}</p>}

      {mixUrl && (
        <div className="mt-4 space-y-2">
          <audio src={mixUrl} controls className="w-full" />
          <a
            href={mixUrl}
            download="dubdesk-overlay-mix.wav"
            className="inline-block rounded-md border px-3 py-2 text-xs font-medium"
          >
            মিক্স ডাউনলোড করুন (WAV)
          </a>
        </div>
      )}
    </section>
  );
}
