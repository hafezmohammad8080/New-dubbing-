import { useServerFn } from "@tanstack/react-start";
import { useMemo, useRef, useState } from "react";

import { analyzeChunk, type NonVerbal, type Segment } from "@/lib/dub.functions";
import { fmtTime, hybridChunks, mixTimeline, probeDuration } from "@/lib/audio";
import { downloadSRT } from "@/lib/utils";
import { type AudioCoreAnalysis } from "@/lib/audio-analyzer";
import { useAudioAnalyzer } from "@/hooks/useAudioAnalyzer";
import { SpeakerProfileTag } from "@/components/SpeakerProfileTag";
import VoiceSuggestionTable from "@/components/VoiceSuggestionTable";
import type { SpeakerProfileInput } from "@/lib/fallback-voice-engine";

import { generateAIResponse } from "@/lib/api-router";
import { AI_PROMPTS } from "@/lib/ai-prompts";
import OverlayStudio from "@/components/OverlayStudio";
import { useBackgroundExecution } from "@/hooks/useBackgroundExecution";
import { PRE_BUFFER_MS, speak, speakAndPlay } from "@/lib/engine";
import { applyPitchPreservedRate } from "@/lib/duration-align";
import {
  speakWithBrowser,
  browserSTTAvailable,
  startBrowserSTT,
  type BrowserSTTHandle,
} from "@/lib/speech-fallback";
import {
  CATEGORIES,
  LANGS,
  VOICES,
  voiceById,
  voicesByCategory,
  type CategoryId,
  type LangId,
} from "@/lib/voices";

type Status = { phase: "idle" | "analyzing" | "dubbing" | "done" | "error"; msg: string; pct: number };

export default function DubbingView() {
  const analyze = useServerFn(analyzeChunk);
  const bg = useBackgroundExecution();
  // #12 Pitch & Frequency Analysis: F0 -> Male / Female / Child tag.
  const pitch = useAudioAnalyzer();
  // Server-function endpoint, used when the request is offloaded to the worker.
  const analyzeUrl = (analyzeChunk as unknown as { url?: string }).url ?? null;


  const [file, setFile] = useState<File | null>(null);
  const [lang, setLang] = useState<LangId>("bn");
  const [selected, setSelected] = useState<string[]>([]);
  const [segments, setSegments] = useState<Segment[]>([]);
  const [duration, setDuration] = useState(0);
  const [assign, setAssign] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Status>({ phase: "idle", msg: "", pct: 0 });
  const [previewing, setPreviewing] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [dubBlob, setDubBlob] = useState<Blob | null>(null);
  const [nonverbal, setNonverbal] = useState<NonVerbal[]>([]);
  const [openCat, setOpenCat] = useState<CategoryId | null>("adult_male");
  const [srtOpen, setSrtOpen] = useState(false);
  const [audioInfo, setAudioInfo] = useState<AudioCoreAnalysis | null>(null);
  const [aiScript, setAiScript] = useState<string>("");
  const [dictating, setDictating] = useState(false);
  const [dictation, setDictation] = useState("");

  /**
   * MODULE 17 — profiles handed to the Fallback Voice Engine. Derived from the
   * existing pitch detection; the "DeepVillain" trait is flagged for unusually
   * low F0 speakers, which the internal neural catalog cannot represent.
   */
  const fallbackProfiles = useMemo<SpeakerProfileInput[]>(() => {
    const p = pitch.pitchProfile;
    if (!p || p.profile === "Unknown") return [];
    const gender: "Male" | "Female" = p.profile === "Male" ? "Male" : "Female";
    const age: "Adult" | "Child" = p.profile === "Child" ? "Child" : "Adult";
    return [
      {
        id: `speaker-main-${lang}`,
        label: `Main speaker — ${p.label}`,
        language: lang,
        gender,
        age,
        f0: p.f0,
        trait: p.f0 && p.f0 < 95 ? "DeepVillain" : "Neutral",
      },
    ];
  }, [pitch.pitchProfile, lang]);


  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInput = useRef<HTMLInputElement | null>(null);
  const sttRef = useRef<BrowserSTTHandle | null>(null);

  /**
   * AUDIO QUEUE (glitch-free playback) — dubbing mode only.
   *
   * Every chunk is rendered to the speaker strictly one-at-a-time. A new chunk
   * is only triggered after (a) the previous one has fully finished (no clipped
   * segment ends), and (b) the pre-buffer readiness state is reached, so the
   * decoded buffer is ready before the first sample plays (no overlap / pop).
   * Nothing about translation, sync maths or layout is involved here.
   */
  const audioQueue = useRef<Promise<void>>(Promise.resolve());

  /** Serialize any speaker-bound task on the single dubbing audio queue. */
  function enqueueAudio<T>(task: () => Promise<T>): Promise<T> {
    const run = audioQueue.current.then(task, task);
    audioQueue.current = run.then(
      () => undefined,
      () => undefined,
    );
    return run;
  }

  /** Resolve once the element is buffered enough to play without clipping. */
  function waitForPreBufferReady(el: HTMLAudioElement | null): Promise<void> {
    if (!el) return new Promise((r) => setTimeout(r, PRE_BUFFER_MS));
    if (el.readyState >= 3 /* HAVE_FUTURE_DATA */) return Promise.resolve();
    return new Promise<void>((resolve) => {
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        el.removeEventListener("canplaythrough", done);
        el.removeEventListener("loadeddata", done);
        el.removeEventListener("error", done);
        resolve();
      };
      el.addEventListener("canplaythrough", done, { once: true });
      el.addEventListener("loadeddata", done, { once: true });
      el.addEventListener("error", done, { once: true });
      // Safety valve: never hang the queue if the element stays silent.
      setTimeout(done, 4000);
    });
  }

  /** Resolve when the currently playing element has fully drained. */
  function waitForPlaybackEnd(el: HTMLAudioElement | null): Promise<void> {
    if (!el || el.paused || el.ended) return Promise.resolve();
    return new Promise<void>((resolve) => {
      let settled = false;
      const done = () => {
        if (settled) return;
        settled = true;
        el.removeEventListener("ended", done);
        el.removeEventListener("pause", done);
        el.removeEventListener("error", done);
        resolve();
      };
      el.addEventListener("ended", done, { once: true });
      el.addEventListener("pause", done, { once: true });
      el.addEventListener("error", done, { once: true });
    });
  }

  /**
   * STT fallback: when the AI analysis path has no key / fails, the user can
   * dictate the dialogue with the browser's native Web Speech recognition.
   * The captured text becomes a normal segment, so dubbing continues.
   */
  async function toggleDictation() {
    if (dictating) {
      sttRef.current?.stop();
      return;
    }
    if (!browserSTTAvailable()) {
      setStatus({ phase: "error", msg: "এই ব্রাউজারে Web Speech STT নেই।", pct: 0 });
      return;
    }
    setDictating(true);
    setDictation("");
    const handle = startBrowserSTT({ lang, onPartial: setDictation });
    sttRef.current = handle;
    const text = await handle.done;
    sttRef.current = null;
    setDictating(false);
    if (text.trim()) {
      setSegments((prev) => {
        const start = prev.length ? Math.max(...prev.map((s) => s.end)) + 0.2 : 0;
        const end = start + Math.max(1.5, text.length / 12);
        setDuration((d) => Math.max(d, end));
        return [
          ...prev,
          {
            start,
            end,
            speaker: "SPK1",
            category: "adult_male",
            source: text,
            text,
            emotion: "calm",
            intensity: 1,
          },
        ];
      });
    }
  }


  const speakers = useMemo(() => {
    const map = new Map<string, { category: CategoryId; lines: number }>();
    for (const s of segments) {
      const cur = map.get(s.speaker);
      map.set(s.speaker, { category: cur?.category ?? s.category, lines: (cur?.lines ?? 0) + 1 });
    }
    return [...map.entries()].map(([id, v]) => ({ id, ...v }));
  }, [segments]);

  const suggested = useMemo(() => {
    const used = new Set<string>();
    const out: Record<string, string> = {};
    for (const sp of speakers) {
      const pool = voicesByCategory(sp.category);
      const pick = pool.find((v) => !used.has(v.id)) ?? pool[0];
      if (pick) {
        used.add(pick.id);
        out[sp.id] = pick.id;
      }
    }
    return out;
  }, [speakers]);

  const toggleVoice = (id: string) =>
    setSelected((prev) => (prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]));

  async function preview(voiceId: string) {
    setPreviewing(voiceId);
    // MODULE 4: keep pitch locked on the shared preview element (no chipmunk
    // effect if a stretch rate is applied later).
    applyPitchPreservedRate(audioRef.current, 1);
    // Queued: the previous chunk drains first, then the pre-buffer readiness
    // state gates the new one — no clipping, no overlapping voices.
    const source = await enqueueAudio(async () => {
      const el = audioRef.current;
      await waitForPlaybackEnd(el);
      // Never blocks: server audio → free public audio → browser voice.
      // `false` = strict DUBBING mode (never the explainer playback path).
      const src = await speakAndPlay(
        { voiceId, lang, emotion: "warm and friendly", intensity: 1 },
        el,
        false,
      );
      await waitForPreBufferReady(el);
      await waitForPlaybackEnd(el);
      return src;
    });
    if (source === "browser") {
      setStatus({
        phase: "idle",
        msg: "এআই ভয়েস পাওয়া যায়নি — ব্রাউজারের নিজস্ব ভয়েসে প্রিভিউ শোনানো হচ্ছে।",
        pct: 0,
      });
    }
    setPreviewing(null);
  }


  async function runAnalysis() {
    if (!file) return;
    // Wake lock + worker heartbeat + silent audio loop for the whole run.
    const releaseBg = bg.begin("dubbing:analysis");
    setResult(null);
    setDubBlob(null);
    setSegments([]);
    setNonverbal([]);
    setStatus({ phase: "analyzing", msg: "অডিও ডিকোড হচ্ছে…", pct: 2 });
    try {
      // MODULE 6: memory-safe streaming — 1-minute File.slice() chunks are
      // parked in IndexedDB and processed strictly one-by-one (FIFO), each
      // deleted + released before the next is touched.
      const dur = await probeDuration(file);
      if (dur) setDuration(dur);
      const all: Segment[] = [];
      const allNv: NonVerbal[] = [];
      let done = 0;
      for await (const chunk of hybridChunks(file, 60)) {
        setStatus({
          phase: "analyzing",
          msg: `অংশ ${done + 1}/${chunk.total} বিশ্লেষণ হচ্ছে (টাইমস্ট্যাম্পসহ)…`,
          pct: Math.round((done / chunk.total) * 100),
        });
        try {
          const payload = { audioBase64: chunk.base64, mime: "wav", offset: chunk.offset, lang };
          // Prefer the Web Worker thread (keeps running while the tab sleeps);
          // fall back to the normal main-thread RPC when it is unavailable.
          const offloaded = analyzeUrl
            ? await bg.offloadJson<{ segments?: Segment[]; nonverbal?: NonVerbal[] }>(analyzeUrl, {
                data: payload,
              })
            : null;
          const { segments: segs, nonverbal: nv } =
            offloaded ?? (await analyze({ data: payload }));
          all.push(...(segs ?? []));
          allNv.push(...(nv ?? []));
        } catch (err) {
          console.warn("[dubbing] chunk analysis failed, continuing:", err);
        }

        setSegments([...all].sort((a, b) => a.start - b.start));
        setNonverbal([...allNv].sort((a, b) => a.start - b.start));
        done++;
      }
      if (!dur) setDuration(all.reduce((m, s) => Math.max(m, s.end), 0));

      try {
        const transcript = all.map((s) => s.text).join(" ");
        if (transcript.trim()) {
          setAiScript(await generateAIResponse(transcript, AI_PROMPTS.DUBBING_MODE));
        }
      } catch (err) {
        setAiScript(`স্ক্রিপ্ট তৈরি করা যায়নি: ${err instanceof Error ? err.message : "unknown"}`);
      }
      setStatus({
        phase: "done",
        msg: all.length
          ? `${all.length}টি ডায়লগ ও ${allNv.length}টি নন-ভার্বাল মুহূর্ত পাওয়া গেছে।`
          : browserSTTAvailable()
            ? "এআই বিশ্লেষণ পাওয়া যায়নি — নিচের মাইক ডিকটেশন (ব্রাউজার STT) দিয়ে লাইন যোগ করতে পারেন।"
            : "এআই বিশ্লেষণ পাওয়া যায়নি।",
        pct: 100,
      });

    } catch (err) {
      setStatus({
        phase: "error",
        msg: `বিশ্লেষণ ব্যর্থ: ${err instanceof Error ? err.message : "unknown"}`,
        pct: 0,
      });
    } finally {
      releaseBg();
    }
  }

  async function runDubbing() {
    if (!segments.length) return;
    const releaseBg = bg.begin("dubbing:render");
    setResult(null);
    setDubBlob(null);
    setStatus({ phase: "dubbing", msg: "ভয়েস তৈরি হচ্ছে…", pct: 0 });
    const clips: { start: number; audio: ArrayBuffer; target: number }[] = [];
    let browserLines = 0;
    try {
      for (let i = 0; i < segments.length; i++) {
        const seg = segments[i]!;
        const voiceId =
          assign[seg.speaker] ??
          suggested[seg.speaker] ??
          selected.find((id) => voiceById(id)?.category === seg.category) ??
          voicesByCategory(seg.category)[0]!.id;

        const out = await speak({
          voiceId,
          lang,
          text: seg.text,
          emotion: seg.emotion,
          intensity: seg.intensity,
          quality: "pro",
        });

        if (out.audio && out.audio.byteLength > 0) {
          clips.push({
            start: seg.start,
            audio: out.audio,
            target: Math.max(0.3, seg.end - seg.start),
          });
        } else {
          // No key / 429 / provider down → speak this line with the browser
          // voice so the run continues instead of failing.
          browserLines++;
          // Queued too: fallback lines never overlap the previous chunk.
          void enqueueAudio(() => speakWithBrowser(seg.text, { lang }));
        }
        setStatus({
          phase: "dubbing",
          msg: `ডায়লগ ${i + 1}/${segments.length} — ${fmtTime(seg.start)}`,
          pct: Math.round(((i + 1) / segments.length) * 100),
        });
      }
      const blob = await mixTimeline(clips, duration);
      setDubBlob(blob);
      setResult(URL.createObjectURL(blob));
      setStatus({
        phase: "done",
        msg: browserLines
          ? `ডাবিং সম্পন্ন! ${browserLines}টি লাইন ব্রাউজার ভয়েসে ফলব্যাক হয়েছে।`
          : "ডাবিং সম্পন্ন! টাইমিং মূল অডিও অনুযায়ী বসানো হয়েছে।",
        pct: 100,
      });

    } catch (err) {
      setStatus({
        phase: "error",
        msg: `ডাবিং ব্যর্থ: ${err instanceof Error ? err.message : "unknown"}`,
        pct: 0,
      });
    } finally {
      releaseBg();
    }
  }

  const busy = status.phase === "analyzing" || status.phase === "dubbing";

  return (
    <main className="mx-auto max-w-3xl px-4 pt-10 pb-24">
      <audio ref={audioRef} hidden />

      <header className="text-center">
        <span className="inline-block rounded-full border px-3 py-1 text-xs text-muted-foreground">
          ✦ এআই ডাবিং স্টুডিও
        </span>
        <h1 className="gold-text mt-4 text-5xl font-bold">DubDesk</h1>
        <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">
          যেকোনো দৈর্ঘ্যের অডিও দিন — সেকেন্ড-বাই-সেকেন্ড টাইমস্ট্যাম্প, অনুবাদ ও বয়স-লিঙ্গ মিলিয়ে
          মানুষের মতো আবেগভরা ভয়েসে ডাবিং।
        </p>
      </header>

      {/* 1. Source */}
      <section className="panel mt-8">
        <h2 className="text-lg font-semibold">১. সোর্স</h2>
        <input
          ref={fileInput}
          type="file"
          accept="audio/*,video/*"
          hidden
          onChange={(e) => {
            const picked = e.target.files?.[0] ?? null;
            setFile(picked);
            setAudioInfo(null);
            setAiScript("");
            pitch.reset();
            if (picked) {
              void pitch
                .analyzeFile(picked)
                .then(setAudioInfo)
                .catch(() => setAudioInfo(null));
            }
            setSegments([]);
            setNonverbal([]);
            setResult(null);
            setDubBlob(null);
            setStatus({ phase: "idle", msg: "", pct: 0 });
          }}
        />
        <button
          type="button"
          onClick={() => fileInput.current?.click()}
          className="mt-4 flex w-full flex-col items-center gap-1 rounded-xl border border-dashed bg-secondary/40 px-4 py-8 transition-colors hover:border-primary"
        >
          <span className="text-base font-medium">{file ? file.name : "↑ ফাইল আপলোড করুন"}</span>
          <span className="text-xs text-muted-foreground">
            MP3, WAV, M4A, MP4 — কোনো সাইজ লিমিট নেই, ২–৩ ঘণ্টার অডিও ছোট ছোট ভাগে প্রসেস হবে
          </span>
        </button>

        {(pitch.analyzing || pitch.pitchProfile) && (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">Speaker profile:</span>
            <SpeakerProfileTag profile={pitch.pitchProfile} loading={pitch.analyzing} />
          </div>
        )}

        {fallbackProfiles.length > 0 && (
          <VoiceSuggestionTable className="mt-5" profiles={fallbackProfiles} />
        )}


        {audioInfo && (
          <p className="mt-3 text-xs text-muted-foreground">
            Emotion: <span className="text-foreground">{audioInfo.detectedEmotion}</span> · Gender:{" "}
            <span className="text-foreground">{audioInfo.detectedGender}</span> · Pitch:{" "}
            {audioInfo.pitchHz} Hz
          </p>
        )}

        {aiScript && (
          <textarea
            readOnly
            value={aiScript}
            rows={8}
            className="mt-4 w-full rounded-lg border bg-secondary/40 px-3 py-2 text-sm outline-none"
          />
        )}

        <h3 className="mt-6 text-xs text-muted-foreground">ডাবিং ভাষা</h3>
        <div className="mt-2 flex gap-2">
          {LANGS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => setLang(l.id)}
              className={`rounded-lg border px-4 py-2 text-sm transition-colors ${
                lang === l.id ? "gold-fill border-transparent font-semibold" : "hover:bg-secondary"
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>

        <button
          type="button"
          disabled={!file || busy}
          onClick={runAnalysis}
          className="gold-fill mt-6 w-full rounded-xl py-3 text-sm font-semibold disabled:opacity-40"
        >
          অডিও বিশ্লেষণ করুন (টাইমস্ট্যাম্প + ভয়েস সাজেশন)
        </button>

        {/* STT fallback — native Web Speech dictation when AI STT is unavailable */}
        <button
          type="button"
          disabled={busy}
          onClick={toggleDictation}
          className="mt-3 w-full rounded-xl border py-3 text-sm font-medium disabled:opacity-40"
        >
          {dictating ? "⏹ ডিকটেশন থামান" : "🎙 মাইক ডিকটেশন (ব্রাউজার STT ফলব্যাক)"}
        </button>
        {(dictating || dictation) && (
          <p className="mt-2 text-xs text-muted-foreground">{dictation || "শুনছি…"}</p>
        )}
      </section>


      {/* 2. Voices */}
      <section className="panel mt-6">
        <h2 className="text-lg font-semibold">২. ভয়েস বাছাই</h2>
        <p className="mt-1 text-xs text-muted-foreground">
          ৮টি বয়স-লিঙ্গ ক্যাটাগরি, প্রতিটিতে ৪টি আলাদা ভয়েস। শুনতে ▶ চাপুন, পছন্দ হলে সিলেক্ট করুন।
          ({selected.length}টি সিলেক্টেড)
        </p>

        <div className="mt-4 space-y-2">
          {CATEGORIES.map((cat) => {
            const open = openCat === cat.id;
            return (
              <div key={cat.id} className="overflow-hidden rounded-xl border">
                <button
                  type="button"
                  onClick={() => setOpenCat(open ? null : cat.id)}
                  className="flex w-full items-center justify-between bg-secondary/40 px-4 py-3 text-left"
                >
                  <span className="text-sm font-semibold">
                    {cat.label}{" "}
                    <span className="font-normal text-muted-foreground">({cat.ageLabel})</span>
                  </span>
                  <span className="text-muted-foreground">{open ? "▾" : "▸"}</span>
                </button>
                {open && (
                  <div className="grid gap-2 p-3 sm:grid-cols-2">
                    {voicesByCategory(cat.id).map((v) => {
                      const on = selected.includes(v.id);
                      return (
                        <div
                          key={v.id}
                          className={`flex items-center justify-between gap-2 rounded-lg border px-3 py-2 ${
                            on ? "border-primary bg-secondary/60" : ""
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() => toggleVoice(v.id)}
                            className="flex-1 text-left"
                          >
                            <div className="text-sm font-medium">{v.name}</div>
                            <div className="text-xs text-muted-foreground">{v.tone}</div>
                          </button>
                          <button
                            type="button"
                            onClick={() => preview(v.id)}
                            disabled={previewing !== null}
                            className="rounded-md border px-2 py-1 text-xs disabled:opacity-40"
                          >
                            {previewing === v.id ? "…" : "▶"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. Suggestions + script */}
      {segments.length > 0 && (
        <section className="panel mt-6">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="text-lg font-semibold">৩. এআই সাজেশন ও স্ক্রিপ্ট</h2>

            <div className="relative ml-auto">
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  setSrtOpen((v) => !v);
                }}
                className="rounded-md border px-3 py-1.5 text-xs font-medium"
              >
                সাবটাইটেল ডাউনলোড ▾
              </button>

              {srtOpen && (
                <div className="absolute right-0 z-20 mt-1 w-56 overflow-hidden rounded-lg border bg-card shadow-lg">
                  {(
                    [
                      { id: "bn", label: "বাংলা (.SRT)" },
                      { id: "en", label: "English (.SRT)" },
                      { id: "both", label: "Dual Subtitle (বাংলা + English)" },
                    ] as const
                  ).map((opt) => (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={(e) => {
                        e.preventDefault();
                        setSrtOpen(false);
                        try {
                          downloadSRT(segments || [], opt.id);
                        } catch (err) {
                          console.error("SRT export failed", err);
                        }
                      }}
                      className="block w-full px-3 py-2 text-left text-xs hover:bg-secondary"
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            অডিও বিশ্লেষণ করে প্রতিটি চরিত্রের বয়স ও লিঙ্গ অনুযায়ী ভয়েস সাজেস্ট করা হয়েছে — চাইলে বদলান।
          </p>

          <div className="mt-4 space-y-2">
            {speakers.map((sp) => {
              const cat = CATEGORIES.find((c) => c.id === sp.category)!;
              const value = assign[sp.id] ?? suggested[sp.id] ?? "";
              return (
                <div
                  key={sp.id}
                  className="flex flex-wrap items-center gap-2 rounded-lg border bg-secondary/30 px-3 py-2"
                >
                  <span className="text-sm font-medium">{sp.id}</span>
                  <span className="text-xs text-muted-foreground">
                    {cat.label} · {sp.lines} লাইন
                  </span>
                  <select
                    value={value}
                    onChange={(e) => setAssign((p) => ({ ...p, [sp.id]: e.target.value }))}
                    className="ml-auto rounded-md border bg-card px-2 py-1 text-sm"
                  >
                    {VOICES.filter((v) => v.category === sp.category).map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} — {v.tone}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => value && preview(value)}
                    className="rounded-md border px-2 py-1 text-xs"
                  >
                    ▶
                  </button>
                </div>
              );
            })}
          </div>

          <div className="mt-5 max-h-80 space-y-2 overflow-y-auto pr-1">
            {segments.map((s, i) => (
              <div key={`${s.start}-${i}`} className="rounded-lg border px-3 py-2 text-sm">
                <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                  <span className="rounded bg-secondary px-1.5 py-0.5 font-mono">
                    {fmtTime(s.start)} → {fmtTime(s.end)}
                  </span>
                  <span>{s.speaker}</span>
                  <span>· {s.emotion}</span>
                </div>
                <p className="mt-1">{s.text}</p>
                <p className="text-xs text-muted-foreground">{s.source}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 4. Dub */}
      <section className="panel mt-6">
        <h2 className="text-lg font-semibold">৪. ডাবিং</h2>
        <button
          type="button"
          disabled={!segments.length || busy}
          onClick={runDubbing}
          className="gold-fill mt-4 w-full rounded-xl py-3 text-sm font-semibold disabled:opacity-40"
        >
          ডাবিং শুরু করুন
        </button>

        {status.msg && (
          <div className="mt-4">
            <div className="h-2 overflow-hidden rounded-full bg-secondary">
              <div
                className="gold-fill h-full transition-all"
                style={{ width: `${status.pct}%` }}
              />
            </div>
            <p
              className={`mt-2 text-xs ${
                status.phase === "error" ? "text-destructive" : "text-muted-foreground"
              }`}
            >
              {status.msg}
            </p>
          </div>
        )}

        {result && (
          <div className="mt-4 space-y-3">
            <audio
              src={result}
              controls
              className="w-full"
              ref={(el) => {
                applyPitchPreservedRate(el, 1);
              }}

            />
            <a
              href={result}
              download="dubdesk-dub.wav"
              className="block rounded-xl border py-3 text-center text-sm font-semibold"
            >
              ↓ ডাউনলোড করুন
            </a>
          </div>
        )}
      </section>

      {/* 5. Non-verbal retention & overlay */}
      <OverlayStudio
        originalFile={file}
        dubBlob={dubBlob}
        hints={nonverbal.map((n) => ({ start: n.start, end: n.end, kind: n.kind }))}
      />
    </main>
  );
}
