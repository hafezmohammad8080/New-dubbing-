import type { PitchProfile } from "@/hooks/useAudioAnalyzer";
import { cn } from "@/lib/utils";

/**
 * Dashboard tag for the auto-detected speaker profile, e.g. "Male (120Hz)".
 * Purely presentational — additive to the existing dashboard.
 */
export function SpeakerProfileTag({
  profile,
  loading,
  className,
}: {
  profile: PitchProfile | null;
  loading?: boolean;
  className?: string;
}) {
  if (loading) {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full border bg-secondary/60 px-2.5 py-1 text-xs text-muted-foreground",
          className,
        )}
      >
        <span className="size-1.5 animate-pulse rounded-full bg-muted-foreground" />
        পিচ বিশ্লেষণ হচ্ছে…
      </span>
    );
  }

  if (!profile) return null;

  const tone =
    profile.profile === "Male"
      ? "border-chart-3/40 bg-chart-3/10 text-chart-3"
      : profile.profile === "Female"
        ? "border-chart-5/40 bg-chart-5/10 text-chart-5"
        : profile.profile === "Child"
          ? "border-chart-2/40 bg-chart-2/10 text-chart-2"
          : "border-border bg-secondary/60 text-muted-foreground";

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium",
        tone,
        className,
      )}
      title={`F0 ≈ ${profile.f0} Hz · Meyda / autocorrelation`}
    >
      <span className="size-1.5 rounded-full bg-current" />
      {profile.label}
    </span>
  );
}
