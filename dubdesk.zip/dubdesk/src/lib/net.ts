/**
 * MODULE 3 — Smart error recovery & request throttling.
 *
 * Single shared networking layer used by every external API caller
 * (api-router, translate-fallback, tts.server, engine). Nothing here is
 * duplicated in those files: they import from this module.
 *
 * Provides:
 *  1. resilientFetch() — try/catch wrapped fetch that treats 429 and 5xx as
 *     retryable, honours Retry-After, and retries with exponential backoff
 *     (1s, 2s, 4s … + jitter). Throws only after every retry failed, so the
 *     caller's existing fallback engine takes over automatically.
 *  2. RequestQueue — sequential queue with a configurable delay between
 *     requests (default 650ms, clamped to 500–1000ms) to prevent flooding an
 *     API with a whole batch of dialogue chunks at once.
 *  3. withRecovery() — run any async task with the same backoff policy and a
 *     guaranteed fallback value.
 */

export type RetryOptions = {
  /** Number of retries AFTER the first attempt. Default 2 (1s, 2s). */
  retries?: number;
  /** First backoff delay in ms. Default 1000 → 1s, 2s, 4s … */
  baseDelayMs?: number;
  /** Upper bound for a single backoff wait. Default 8000. */
  maxDelayMs?: number;
  /** Label used in console warnings. */
  label?: string;
  /** AbortSignal-friendly timeout per attempt in ms. Default 45000. */
  timeoutMs?: number;
};

export const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504, 522, 524]);

export function isRetryableStatus(status: number): boolean {
  return RETRYABLE_STATUS.has(status) || status >= 500;
}

export const sleep = (ms: number) =>
  new Promise<void>((resolve) => setTimeout(resolve, Math.max(0, ms)));

/** Exponential backoff with light jitter. */
export function backoffDelay(attempt: number, base = 1000, max = 8000): number {
  const raw = base * Math.pow(2, attempt);
  return Math.min(max, Math.round(raw + Math.random() * 200));
}

/** `Retry-After` may be seconds or an HTTP date. */
function retryAfterMs(res: Response): number | null {
  const header = res.headers.get("retry-after");
  if (!header) return null;
  const asNumber = Number(header);
  if (Number.isFinite(asNumber)) return Math.min(15000, asNumber * 1000);
  const asDate = Date.parse(header);
  if (!Number.isNaN(asDate)) return Math.min(15000, Math.max(0, asDate - Date.now()));
  return null;
}

export class HttpError extends Error {
  status: number;
  body: string;
  constructor(status: number, body: string, label = "request") {
    super(`${label} failed [${status}]${body ? `: ${body.slice(0, 200)}` : ""}`);
    this.name = "HttpError";
    this.status = status;
    this.body = body;
  }
}

/**
 * fetch() with global error catching + automatic retry on 429 / 5xx / network
 * failures. Non-retryable responses (400, 401, 403 …) throw immediately so the
 * caller can fall back without wasting time.
 */
export async function resilientFetch(
  input: string,
  init: RequestInit = {},
  options: RetryOptions = {},
): Promise<Response> {
  const {
    retries = 2,
    baseDelayMs = 1000,
    maxDelayMs = 8000,
    label = "fetch",
    timeoutMs = 45000,
  } = options;

  let lastError: unknown;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(input, { ...init, signal: init.signal ?? controller.signal });

      if (res.ok) return res;

      const body = await res.text().catch(() => "");
      const error = new HttpError(res.status, body, label);

      if (!isRetryableStatus(res.status) || attempt === retries) throw error;

      const wait = retryAfterMs(res) ?? backoffDelay(attempt, baseDelayMs, maxDelayMs);
      console.warn(
        `[net] ${label} got ${res.status} — retry ${attempt + 1}/${retries} in ${wait}ms`,
      );
      lastError = error;
      await sleep(wait);
      continue;
    } catch (err) {
      // Non-retryable HTTP errors bubble up straight away.
      if (err instanceof HttpError && !isRetryableStatus(err.status)) throw err;
      lastError = err;
      if (attempt === retries) break;
      const wait = backoffDelay(attempt, baseDelayMs, maxDelayMs);
      console.warn(
        `[net] ${label} network error — retry ${attempt + 1}/${retries} in ${wait}ms`,
        err,
      );
      await sleep(wait);
    } finally {
      clearTimeout(timer);
    }
  }

  throw lastError instanceof Error ? lastError : new Error(`${label} failed`);
}

/** Convenience: resilientFetch + JSON parse. */
export async function resilientJson<T>(
  input: string,
  init: RequestInit = {},
  options: RetryOptions = {},
): Promise<T> {
  const res = await resilientFetch(input, init, options);
  return (await res.json()) as T;
}

/**
 * Run any async task with retry + exponential backoff. If every attempt fails
 * the fallback is returned (never throws) — this is what hands control to the
 * fallback engine automatically.
 */
export async function withRecovery<T>(
  task: () => Promise<T>,
  fallback: () => Promise<T> | T,
  options: RetryOptions = {},
): Promise<T> {
  const { retries = 2, baseDelayMs = 1000, maxDelayMs = 8000, label = "task" } = options;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await task();
    } catch (err) {
      if (err instanceof HttpError && !isRetryableStatus(err.status)) {
        console.warn(`[net] ${label} non-retryable, using fallback:`, err.message);
        break;
      }
      if (attempt === retries) {
        console.warn(`[net] ${label} exhausted retries, using fallback:`, err);
        break;
      }
      await sleep(backoffDelay(attempt, baseDelayMs, maxDelayMs));
    }
  }
  return await fallback();
}

/** Delay between queued requests, clamped to the 500–1000ms anti-flood window. */
export const DEFAULT_THROTTLE_MS = 650;
export const clampThrottle = (ms: number) => Math.min(1000, Math.max(500, Math.round(ms)));

/**
 * Sequential request queue: only one request in flight, with a configurable
 * pause between them so batches of dialogue chunks never flood the provider.
 */
export class RequestQueue {
  private chain: Promise<unknown> = Promise.resolve();
  private delayMs: number;
  private lastRunAt = 0;

  constructor(delayMs: number = DEFAULT_THROTTLE_MS) {
    this.delayMs = clampThrottle(delayMs);
  }

  /** Change the throttle at runtime (clamped to 500–1000ms). */
  setDelay(ms: number) {
    this.delayMs = clampThrottle(ms);
  }

  get delay() {
    return this.delayMs;
  }

  add<T>(task: () => Promise<T>): Promise<T> {
    const run = this.chain.then(async () => {
      const since = Date.now() - this.lastRunAt;
      if (this.lastRunAt && since < this.delayMs) await sleep(this.delayMs - since);
      try {
        return await task();
      } finally {
        this.lastRunAt = Date.now();
      }
    });
    // Keep the chain alive even when a task rejects.
    this.chain = run.catch(() => undefined);
    return run as Promise<T>;
  }
}

/** Shared queues so all callers throttle against the same pipeline. */
export const textQueue = new RequestQueue(DEFAULT_THROTTLE_MS);
export const ttsQueue = new RequestQueue(DEFAULT_THROTTLE_MS);
