/**
 * MODULE 4 — non-blocking user notices.
 *
 * Thin pass-through to the existing sonner toast (see components/ui/sonner.tsx,
 * mounted once in __root.tsx). No new UI component is introduced; this only
 * de-duplicates repeated fallback notices so a long render doesn't spam the
 * screen, and it never blocks the running process.
 */
import { toast } from "sonner";

const lastShown = new Map<string, number>();
const COOLDOWN_MS = 8000;

function shouldShow(id: string) {
  const now = Date.now();
  const prev = lastShown.get(id) ?? 0;
  if (now - prev < COOLDOWN_MS) return false;
  lastShown.set(id, now);
  return true;
}

/** Subtle background warning: informative, dismissable, non-blocking. */
export function notifyFallback(message: string, id = "fallback") {
  if (typeof window === "undefined" || !shouldShow(id)) return;
  toast.warning(message, { id, duration: 4000, closeButton: true });
}

/** Neutral info notice (e.g. switched to Default Free Mode). */
export function notifyInfo(message: string, id?: string) {
  if (typeof window === "undefined") return;
  if (id && !shouldShow(id)) return;
  toast(message, id ? { id, duration: 3000 } : { duration: 3000 });
}

/** Positive confirmation (settings saved, keys purged). */
export function notifySuccess(message: string, id?: string) {
  if (typeof window === "undefined") return;
  toast.success(message, id ? { id, duration: 2500 } : { duration: 2500 });
}
