/**
 * MODULE 17 — Fallback Voice Engine.
 *
 * Additive service on top of the existing neural voice mapping
 * (`@/lib/neural-voices` + `@/lib/dubbingLogicHelpers`). Nothing here mutates
 * the existing selection state — it only answers the question:
 *
 *   "This detected speaker profile has NO suitable internal neural voice.
 *    What can the browser give us instead?"
 *
 * Flow:
 *   1. resolveInternalVoice(profile)  -> internal Microsoft Neural voice or null
 *   2. suggestFallbackVoices(profile) -> ranked window.speechSynthesis voices
 *   3. previewBrowserVoice(...)       -> inline audio preview
 *   4. setVoiceOverride(...)          -> manual override (persisted)
 */

import {
  getNeuralVoiceId,
  type AgeGroup,
  type Gender,
  type SupportedLanguage,
} from "@/lib/dubbingLogicHelpers";
import { NEURAL_VOICES, localeOf, type TtsLanguage, type VoiceType } from "@/lib/neural-voices";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Extra character colour that internal neural voices cannot express. */
export type SpeakerTrait =
  | "Neutral"
  | "DeepVillain"
  | "Elderly"
  | "Whisper"
  | "Robotic"
  | "Announcer";

export const SPEAKER_TRAITS: { value: SpeakerTrait; label: string; internal: boolean }[] = [
  { value: "Neutral", label: "Neutral / স্বাভাবিক", internal: true },
  { value: "DeepVillain", label: "Deep Villain / ভিলেন", internal: false },
  { value: "Elderly", label: "Elderly / বয়স্ক", internal: false },
  { value: "Whisper", label: "Whisper / ফিসফিস", internal: false },
  { value: "Robotic", label: "Robotic / যান্ত্রিক", internal: false },
  { value: "Announcer", label: "Announcer / ঘোষক", internal: true },
];

export type SpeakerProfileInput = {
  /** Stable id of the detected speaker / segment. */
  id: string;
  label?: string;
  language: SupportedLanguage;
  gender: Gender;
  age: AgeGroup;
  trait?: SpeakerTrait;
  /** Detected fundamental frequency, used to refine the fallback ranking. */
  f0?: number;
};

export type InternalVoiceMatch = {
  voiceId: string;
  label: string;
};

export type FallbackSuggestion = {
  /** Stable key for the native voice (voiceURI, name as last resort). */
  key: string;
  name: string;
  lang: string;
  localService: boolean;
  /** 0–100 confidence that this native voice fits the profile. */
  score: number;
  reasons: string[];
};

// ---------------------------------------------------------------------------
// 1. Internal neural match
// ---------------------------------------------------------------------------

function voiceTypeOf(gender: Gender, age: AgeGroup): VoiceType {
  return age === "Child" ? "Child" : gender === "Male" ? "Male" : "Female";
}

const TRAIT_SUPPORTED = new Set<SpeakerTrait>(
  SPEAKER_TRAITS.filter((t) => t.internal).map((t) => t.value),
);

/**
 * Returns the internal Microsoft Neural voice for the profile, or `null` when
 * the profile cannot be represented by the internal catalog (unusual traits
 * such as a deep villain voice, or a missing language/type entry).
 */
export function resolveInternalVoice(profile: SpeakerProfileInput): InternalVoiceMatch | null {
  const trait = profile.trait ?? "Neutral";
  if (!TRAIT_SUPPORTED.has(trait)) return null;

  const lang = profile.language as TtsLanguage;
  const type = voiceTypeOf(profile.gender, profile.age);
  const entry = NEURAL_VOICES[lang]?.[type];
  if (!entry) return null;

  return { voiceId: entry.id ?? getNeuralVoiceId(profile.language, profile.gender, profile.age), label: entry.label };
}

export function isUnmapped(profile: SpeakerProfileInput): boolean {
  return resolveInternalVoice(profile) === null;
}

// ---------------------------------------------------------------------------
// 2. Browser-native voice discovery
// ---------------------------------------------------------------------------

export function browserVoicesAvailable(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function voiceKey(v: SpeechSynthesisVoice): string {
  return v.voiceURI || `${v.name}::${v.lang}`;
}

/**
 * `getVoices()` is async on Chromium: it can return [] until the
 * `voiceschanged` event fires. This resolves once voices exist (or times out).
 */
export function loadBrowserVoices(timeoutMs = 2500): Promise<SpeechSynthesisVoice[]> {
  if (!browserVoicesAvailable()) return Promise.resolve([]);
  const synth = window.speechSynthesis;
  const immediate = synth.getVoices();
  if (immediate.length) return Promise.resolve(immediate);

  return new Promise((resolve) => {
    let settled = false;
    const done = (list: SpeechSynthesisVoice[]) => {
      if (settled) return;
      settled = true;
      synth.removeEventListener?.("voiceschanged", onChange);
      resolve(list);
    };
    const onChange = () => done(synth.getVoices());
    synth.addEventListener?.("voiceschanged", onChange);
    window.setTimeout(() => done(synth.getVoices()), timeoutMs);
  });
}

const MALE_HINTS = ["male", "man", "guy", "david", "mark", "george", "ravi", "asad", "pradeep", "madhur", "daniel", "alex", "fred"];
const FEMALE_HINTS = ["female", "woman", "girl", "zira", "heera", "swara", "uzma", "nabanita", "samantha", "victoria", "karen", "aria", "jenny"];
const CHILD_HINTS = ["child", "kid", "junior", "ana", "tanishaa", "kavyanjali"];
const DEEP_HINTS = ["deep", "bass", "grand", "baritone", "george", "rishi", "david"];
const ELDER_HINTS = ["senior", "elder", "grand", "old"];
const WHISPER_HINTS = ["soft", "whisper", "calm", "gentle"];
const ROBOT_HINTS = ["robot", "synth", "compact", "eloquence", "espeak"];

function hits(name: string, hints: string[]): boolean {
  return hints.some((h) => name.includes(h));
}

/**
 * Ranks native voices for a speaker profile. Highest score first.
 * Language match dominates, then gender/age, then trait colour.
 */
export function suggestFallbackVoices(
  profile: SpeakerProfileInput,
  voices: SpeechSynthesisVoice[],
  limit = 6,
): FallbackSuggestion[] {
  if (!voices?.length) return [];

  const locale = localeOf(profile.language as TtsLanguage).toLowerCase();
  const prefix = profile.language.toLowerCase();
  const trait = profile.trait ?? "Neutral";

  const scored = voices.map<FallbackSuggestion>((v) => {
    const name = (v.name ?? "").toLowerCase();
    const lang = (v.lang ?? "").toLowerCase().replace("_", "-");
    let score = 10;
    const reasons: string[] = [];

    if (lang === locale) {
      score += 45;
      reasons.push("exact locale");
    } else if (lang.startsWith(prefix)) {
      score += 32;
      reasons.push("same language");
    } else if (prefix === "bn" && lang.startsWith("hi")) {
      score += 12;
      reasons.push("near language (hi)");
    } else if (prefix === "ur" && lang.startsWith("hi")) {
      score += 12;
      reasons.push("near language (hi)");
    } else if (lang.startsWith("en")) {
      score += 6;
      reasons.push("english base");
    }

    const looksMale = hits(name, MALE_HINTS);
    const looksFemale = hits(name, FEMALE_HINTS);
    if (profile.gender === "Male" && looksMale) {
      score += 18;
      reasons.push("male timbre");
    } else if (profile.gender === "Female" && looksFemale) {
      score += 18;
      reasons.push("female timbre");
    } else if ((profile.gender === "Male" && looksFemale) || (profile.gender === "Female" && looksMale)) {
      score -= 14;
      reasons.push("gender mismatch");
    }

    if (profile.age === "Child" && hits(name, CHILD_HINTS)) {
      score += 14;
      reasons.push("young voice");
    }

    if (trait === "DeepVillain" && hits(name, DEEP_HINTS)) {
      score += 16;
      reasons.push("deep/heavy");
    }
    if (trait === "Elderly" && hits(name, ELDER_HINTS)) {
      score += 14;
      reasons.push("elder tone");
    }
    if (trait === "Whisper" && hits(name, WHISPER_HINTS)) {
      score += 14;
      reasons.push("soft tone");
    }
    if (trait === "Robotic" && hits(name, ROBOT_HINTS)) {
      score += 14;
      reasons.push("synthetic tone");
    }

    if (v.localService) {
      score += 4;
      reasons.push("offline capable");
    }
    if (v.default) score += 2;

    return {
      key: voiceKey(v),
      name: v.name,
      lang: v.lang,
      localService: !!v.localService,
      score: Math.max(0, Math.min(100, score)),
      reasons,
    };
  });

  return scored.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name)).slice(0, limit);
}

// ---------------------------------------------------------------------------
// 3. Inline preview (native engine only — never touches the neural pipeline)
// ---------------------------------------------------------------------------

const PREVIEW_TEXT: Record<SupportedLanguage, string> = {
  bn: "এটি একটি বিকল্প ভয়েস প্রিভিউ।",
  hi: "यह एक वैकल्पिक आवाज़ का पूर्वावलोकन है।",
  ur: "یہ ایک متبادل آواز کا نمونہ ہے۔",
  en: "This is a fallback voice preview.",
};

export function previewTextFor(language: SupportedLanguage): string {
  return PREVIEW_TEXT[language] ?? PREVIEW_TEXT.en;
}

export function cancelPreview(): void {
  if (browserVoicesAvailable()) window.speechSynthesis.cancel();
}

/** Speaks `text` with a specific native voice. Resolves when playback ends. */
export function previewBrowserVoice(
  key: string,
  voices: SpeechSynthesisVoice[],
  text: string,
  opts: { rate?: number; pitch?: number; volume?: number } = {},
): Promise<boolean> {
  if (!browserVoicesAvailable()) return Promise.resolve(false);
  const voice = voices.find((v) => voiceKey(v) === key);
  if (!voice || !text.trim()) return Promise.resolve(false);

  const synth = window.speechSynthesis;
  synth.cancel();

  return new Promise<boolean>((resolve) => {
    const utter = new SpeechSynthesisUtterance(text);
    utter.voice = voice;
    utter.lang = voice.lang;
    utter.rate = opts.rate ?? 1;
    utter.pitch = opts.pitch ?? 1;
    utter.volume = opts.volume ?? 1;
    utter.onend = () => resolve(true);
    utter.onerror = () => resolve(false);
    synth.speak(utter);
  });
}

// ---------------------------------------------------------------------------
// 4. Manual override store (persisted, additive to existing selection state)
// ---------------------------------------------------------------------------

const STORAGE_KEY = "dubdesk.voiceOverrides.v1";

export type VoiceOverride = {
  /** "neural" = internal voice id, "browser" = native voice key. */
  source: "neural" | "browser";
  value: string;
  label: string;
};

export type OverrideMap = Record<string, VoiceOverride>;

export function loadOverrides(): OverrideMap {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as OverrideMap) : {};
  } catch {
    return {};
  }
}

export function saveOverrides(map: OverrideMap): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch {
    /* storage unavailable — overrides stay in-memory */
  }
}

/**
 * Final resolution used by the dubbing pipeline:
 * manual override -> internal neural voice -> best browser fallback.
 */
export function resolveEffectiveVoice(
  profile: SpeakerProfileInput,
  overrides: OverrideMap,
  voices: SpeechSynthesisVoice[],
): VoiceOverride | null {
  const manual = overrides[profile.id];
  if (manual) return manual;

  const internal = resolveInternalVoice(profile);
  if (internal) return { source: "neural", value: internal.voiceId, label: internal.label };

  const best = suggestFallbackVoices(profile, voices, 1)[0];
  return best ? { source: "browser", value: best.key, label: `${best.name} (${best.lang})` } : null;
}
