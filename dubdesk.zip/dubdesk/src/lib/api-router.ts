import { translateFree } from "@/lib/translate-fallback";
import { resilientFetch, textQueue, HttpError } from "@/lib/net";
import { loadSettings } from "@/lib/settings";
import { notifyFallback } from "@/lib/notify";

/**
 * Smart AI routing with optional keys.
 *
 * Order: configured provider (Gemini → Groq) → free public translation
 * endpoints → original text. Keys are always optional and any provider
 * failure (missing key, invalid key, 429 rate limit, network error) silently
 * falls through to the next option, so the dubbing pipeline never halts.
 */

const GEMINI_MODEL = "gemini-1.5-flash";

// MODULE 4: keys come from the shared settings store (sanitized + cached), so
// deleting a key purges it instantly and this router drops to free mode with
// no page refresh.

async function callGemini(prompt: string, systemInstruction: string, key: string) {
  const response = await resilientFetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        systemInstruction: { parts: [{ text: systemInstruction }] },
      }),
    },
    { label: "gemini", retries: 2, baseDelayMs: 1000 },
  );
  const data = (await response.json()) as {
    candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
  };
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text?.trim()) throw new Error("Gemini returned no text");
  return text;
}

async function callGroq(prompt: string, systemInstruction: string, key: string) {
  const response = await resilientFetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: systemInstruction },
        { role: "user", content: prompt },
      ],
    }),
  }, { label: "groq", retries: 2, baseDelayMs: 1000 });
  const data = (await response.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const text = data.choices?.[0]?.message?.content;
  if (!text?.trim()) throw new Error("Groq returned no text");
  return text;
}

/**
 * Generate (or translate) text. Always resolves with usable text — it never
 * throws because of a missing or invalid API key.
 */
export async function generateAIResponse(
  prompt: string,
  systemInstruction: string,
  options: { targetLang?: string; sourceLang?: string } = {},
): Promise<string> {
  const settings = loadSettings();
  const modelPreference = settings.model;
  const geminiKey = settings.geminiKey;
  const groqKey = settings.groqKey;

  // Build the provider attempt order from the preference; keys are optional,
  // so a provider without a key is simply skipped.
  const order: Array<() => Promise<string>> = [];
  const tryGemini = () => callGemini(prompt, systemInstruction, geminiKey);
  const tryGroq = () => callGroq(prompt, systemInstruction, groqKey);

  if (modelPreference === "gemini") {
    if (geminiKey) order.push(tryGemini);
    if (groqKey) order.push(tryGroq);
  } else if (modelPreference === "groq") {
    if (groqKey) order.push(tryGroq);
    if (geminiKey) order.push(tryGemini);
  } else if (modelPreference !== "free") {
    // auto — prefer Gemini when a key exists, otherwise Groq, otherwise free.
    if (geminiKey) order.push(tryGemini);
    if (groqKey) order.push(tryGroq);
  }

  // MODULE 3: every provider call goes through the shared throttled queue and
  // each attempt already retries 429/5xx with exponential backoff inside
  // resilientFetch. When all of them fail we drop to the fallback engine.
  for (const attempt of order) {
    try {
      const text = await textQueue.add(attempt);
      if (text.trim()) return text;
    } catch (err) {
      const status = err instanceof HttpError ? err.status : 0;
      console.warn(`[api-router] provider failed (status ${status}), falling back:`, err);
      // MODULE 4: subtle non-blocking notice — the pipeline keeps running.
      notifyFallback(
        status === 429
          ? "API limit reached. Switching to free translation fallback…"
          : "AI provider unavailable. Switching to free translation fallback…",
        "ai-fallback",
      );
    }
  }

  // No key, or every provider failed → free public translation endpoints.
  return translateFree(prompt, options.targetLang ?? "bn", options.sourceLang ?? "auto");
}

/** Direct key-free translation helper for any caller that just needs text. */
export { translateFree };
