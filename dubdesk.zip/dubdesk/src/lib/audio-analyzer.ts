import { classifySpeaker, type SpeakerProfileType } from "@/lib/dubbingLogicHelpers";

export async function analyzeAudioCore(audioBuffer: AudioBuffer) {

  const rawData = audioBuffer.getChannelData(0);
  const sampleRate = audioBuffer.sampleRate;
  let sumSquares = 0;
  for (let i = 0; i < rawData.length; i++) {
    sumSquares += rawData[i]! * rawData[i]!;
  }
  const rms = Math.sqrt(sumSquares / rawData.length);

  let pitchHz = 0;
  if (rms > 0.01) {
    const c = new Float32Array(rawData.length).fill(0);
    for (let i = 0; i < 2000; i++) {
      for (let j = 0; j < 2000 - i; j++) {
        c[i] = c[i]! + rawData[j]! * rawData[j + i]!;
      }
    }
    let d = 0;
    while (c[d]! > c[d + 1]!) d++;
    let maxval = -1;
    let maxpos = -1;
    for (let i = d; i < 2000; i++) {
      if (c[i]! > maxval) {
        maxval = c[i]!;
        maxpos = i;
      }
    }
    pitchHz = maxpos > 0 ? sampleRate / maxpos : 0;
  }

  let emotion = "Normal";
  let speakingPace = "Standard";

  if (rms > 0.3) {
    emotion = "Shouting / Intense";
    speakingPace = "Fast";
  } else if (rms < 0.05) {
    emotion = "Whispering / Calm";
    speakingPace = "Slow";
  }

  // MODULE 6 (#12): F0 -> speaker profile through the shared classifier.
  const speakerProfile: SpeakerProfileType | "Unknown" =
    pitchHz > 0 ? classifySpeaker(pitchHz) : "Unknown";
  const GENDER_LABEL: Record<SpeakerProfileType, string> = {
    Male: "Male (Deep/Standard)",
    Female: "Female (Standard)",
    Child: "Child / High-Pitch Female",
  };
  const detectedGender =
    speakerProfile === "Unknown" ? "Unknown" : GENDER_LABEL[speakerProfile];

  return {
    volumeRMS: rms.toFixed(4),
    pitchHz: Math.round(pitchHz),
    detectedEmotion: emotion,
    suggestedPace: speakingPace,
    detectedGender: detectedGender,
    /** #12: Male / Female / Child derived strictly from F0 thresholds. */
    speakerProfile,
  };
}


export type AudioCoreAnalysis = Awaited<ReturnType<typeof analyzeAudioCore>>;

/** Convenience wrapper: decode a File in the browser and analyze it. */
export async function analyzeAudioFile(file: File): Promise<AudioCoreAnalysis> {
  const AudioCtx =
    window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AudioCtx();
  try {
    const buffer = await ctx.decodeAudioData(await file.arrayBuffer());
    return await analyzeAudioCore(buffer);
  } finally {
    void ctx.close();
  }
}
