/**
 * Unified client-side overlay engine (Feature #1 + #16).
 *
 * Everything runs in the browser: vocal-band detection, deduplicated clip
 * state, click-free 0% ducking and OfflineAudioContext rendering.
 * Single source of truth — no duplicate engine files.
 */

export type OverlayClip = {
  id: string;
  /** Start of the region inside the ORIGINAL audio (seconds). */
  start: number;
  /** End of the region inside the ORIGINAL audio (seconds). */
  end: number;
  /** Where it is placed on the DUBBED timeline (seconds). */
  placeAt: number;
  label: string;
  /** Include in preview/render. */
  enabled: boolean;
};

/** Fixed engine constants — intentionally not user-tunable (minimal UI). */
export const RAMP_MS = 30;
export const DUCK_FLOOR = 0.0001; // ~0% gain (exponential ramps cannot hit 0)
export const VOCAL_LOW_HZ = 300;
export const VOCAL_HIGH_HZ = 3400;

/** Duck starts 10ms before the overlay and releases 20ms after it. */
export const DUCK_LEAD_MS = 10;
export const DUCK_TAIL_MS = 20;

/** Energy must exceed 250%–300% of the speech baseline. */
export const BASELINE_RATIO = 2.75;

/** Sustained window required to reject momentary speech loudness. */
export const MIN_SUSTAIN_MS = 275;

/** Vocal energy must dominate — rejects broadband instrument spikes. */
export const VOCAL_RATIO = 0.45;

export const clipDuration = (c: OverlayClip) => Math.max(0, c.end - c.start);

/* ------------------------------------------------------------------ */
/* IDs + state deduplication                                           */
/* ------------------------------------------------------------------ */

let idSeq = 0;
/** Strictly unique id, validated against ids already present in state. */
export function uniqueId(existing: Iterable<{ id: string }> = []): string {
  const taken = new Set([...existing].map((c) => c.id));
  let id: string;
  do {
    id = `clip_${Date.now().toString(36)}_${(idSeq++).toString(36)}_${Math.random()
      .toString(36)
      .slice(2, 7)}`;
  } while (taken.has(id));
  return id;
}

const SAME_RANGE_TOLERANCE = 0.35; // seconds — 00:22.4 vs 00:22.8 counts as one

export const isSameRange = (
  a: { start: number; end: number },
  b: { start: number; end: number },
) =>
  Math.abs(a.start - b.start) < SAME_RANGE_TOLERANCE &&
  Math.abs(a.end - b.end) < SAME_RANGE_TOLERANCE;

/** Drop duplicate ids and near-identical timestamp ranges, keep order. */
export function dedupeClips<T extends { id: string; start: number; end: number }>(
  clips: T[],
): T[] {
  const seenIds = new Set<string>();
  const out: T[] = [];
  for (const c of clips) {
    if (seenIds.has(c.id)) continue;
    if (out.some((k) => isSameRange(k, c))) continue;
    seenIds.add(c.id);
    out.push(c);
  }
  return out.sort((a, b) => a.start - b.start);
}

/* ------------------------------------------------------------------ */
/* WAV encoding + decoding                                             */
/* ------------------------------------------------------------------ */

export function encodeWavFromBuffer(buffer: AudioBuffer): Blob {
  const channels = Math.min(2, buffer.numberOfChannels);
  const frames = buffer.length;
  const data = new ArrayBuffer(44 + frames * channels * 2);
  const view = new DataView(data);
  const str = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  const byteRate = buffer.sampleRate * channels * 2;
  str(0, "RIFF");
  view.setUint32(4, 36 + frames * channels * 2, true);
  str(8, "WAVEfmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, channels * 2, true);
  view.setUint16(34, 16, true);
  str(36, "data");
  view.setUint32(40, frames * channels * 2, true);

  const chans: Float32Array[] = [];
  for (let c = 0; c < channels; c++) chans.push(buffer.getChannelData(c));

  let off = 44;
  for (let i = 0; i < frames; i++) {
    for (let c = 0; c < channels; c++) {
      const s = Math.max(-1, Math.min(1, chans[c]![i] ?? 0));
      view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      off += 2;
    }
  }
  return new Blob([data], { type: "audio/wav" });
}

let sharedCtx: AudioContext | null = null;
/** One shared AudioContext for the whole app — avoids context leaks. */
export function audioCtx(): AudioContext {
  if (!sharedCtx || sharedCtx.state === "closed") sharedCtx = new AudioContext();
  return sharedCtx;
}

export async function decodeToBuffer(source: File | Blob | ArrayBuffer): Promise<AudioBuffer> {
  const arr = source instanceof ArrayBuffer ? source : await source.arrayBuffer();
  return audioCtx().decodeAudioData(arr.slice(0));
}

export function sliceBuffer(buffer: AudioBuffer, start: number, end: number): AudioBuffer {
  const rate = buffer.sampleRate;
  const from = Math.max(0, Math.floor(start * rate));
  const to = Math.min(buffer.length, Math.ceil(end * rate));
  const len = Math.max(1, to - from);
  const out = new AudioBuffer({
    length: len,
    numberOfChannels: buffer.numberOfChannels,
    sampleRate: rate,
  });
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    out.copyToChannel(buffer.getChannelData(c).subarray(from, to).slice(), c);
  }
  return out;
}

export function sliceToWav(buffer: AudioBuffer, start: number, end: number): Blob {
  return encodeWavFromBuffer(sliceBuffer(buffer, start, end));
}

/* ------------------------------------------------------------------ */
/* Playback engine — explicit stop()/disconnect() cleanup              */
/* ------------------------------------------------------------------ */

/**
 * Owns every live BufferSource. Any new preview stops and disconnects the
 * previous ones, so no double/triple overlapping audio and no buffer leaks.
 */
export class PlaybackEngine {
  private nodes: Array<{ src: AudioBufferSourceNode; gain: GainNode }> = [];

  stopAll() {
    for (const { src, gain } of this.nodes) {
      try {
        src.onended = null;
        src.stop();
      } catch {
        /* already stopped */
      }
      try {
        src.disconnect();
        gain.disconnect();
      } catch {
        /* already detached */
      }
      src.buffer = null;
    }
    this.nodes = [];
  }

  /** Play a buffer with 30ms click-free fades. Stops anything playing first. */
  play(buffer: AudioBuffer, onEnded?: () => void) {
    this.stopAll();
    const ctx = audioCtx();
    void ctx.resume();
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const gain = ctx.createGain();
    const now = ctx.currentTime;
    const ramp = RAMP_MS / 1000;
    const dur = buffer.duration;
    const fade = Math.min(ramp, dur / 3);
    gain.gain.setValueAtTime(DUCK_FLOOR, now);
    gain.gain.exponentialRampToValueAtTime(1, now + fade);
    gain.gain.setValueAtTime(1, now + Math.max(fade, dur - fade));
    gain.gain.exponentialRampToValueAtTime(DUCK_FLOOR, now + dur);
    src.connect(gain).connect(ctx.destination);
    src.onended = () => {
      this.stopAll();
      onEnded?.();
    };
    src.start(now);
    this.nodes.push({ src, gain });
  }
}

/* ------------------------------------------------------------------ */
/* Vocal-band non-verbal detection (bandpass gating)                   */
/* ------------------------------------------------------------------ */

export type EnergyEvent = { start: number; end: number; peak: number };

function rmsFrames(data: Float32Array, rate: number, winSec = 0.05): number[] {
  const win = Math.floor(rate * winSec);
  const frames: number[] = [];
  if (win < 1) return frames;
  for (let i = 0; i + win <= data.length; i += win) {
    let sum = 0;
    for (let j = 0; j < win; j++) {
      const v = data[i + j] ?? 0;
      sum += v * v;
    }
    frames.push(Math.sqrt(sum / win));
  }
  return frames;
}

/**
 * Detect human non-verbal bursts (laughter, crying, screams).
 *
 * A BiquadFilter bandpass (300Hz–3kHz) isolates the human vocal range; a
 * frame only counts when its vocal-band energy dominates the full-band
 * energy, so loud instruments (bass/drums/cymbals) no longer false-positive.
 */
export async function detectNonVerbalMoments(
  buffer: AudioBuffer,
  maxEvents = 12,
): Promise<EnergyEvent[]> {
  const rate = buffer.sampleRate;
  const length = buffer.length;
  if (length < rate * 0.2) return [];

  const render = async (withFilter: boolean) => {
    const off = new OfflineAudioContext(1, length, rate);
    const src = off.createBufferSource();
    src.buffer = buffer;
    if (withFilter) {
      const bp = off.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = Math.sqrt(VOCAL_LOW_HZ * VOCAL_HIGH_HZ);
      bp.Q.value = bp.frequency.value / (VOCAL_HIGH_HZ - VOCAL_LOW_HZ);
      const shape = off.createBiquadFilter();
      shape.type = "peaking";
      shape.frequency.value = 1200;
      shape.Q.value = 1;
      shape.gain.value = 4;
      src.connect(bp).connect(shape).connect(off.destination);
    } else {
      src.connect(off.destination);
    }
    src.start(0);
    const out = await off.startRendering();
    return out.getChannelData(0);
  };

  const [vocal, full] = await Promise.all([render(true), render(false)]);
  const win = 0.05;
  const vFrames = rmsFrames(vocal, rate, win);
  const fFrames = rmsFrames(full, rate, win);
  if (!vFrames.length) return [];

  /** Dynamic speech baseline = median RMS of voiced frames only. */
  const voiced = vFrames.filter((v) => v > 0.005);
  const base = [...(voiced.length ? voiced : vFrames)].sort((a, b) => a - b);
  const baseline = base[Math.floor(base.length / 2)] ?? 0;
  /** Flag only when energy exceeds 250%–300% of the speech baseline. */
  const threshold = Math.max(baseline * BASELINE_RATIO, 0.02);
  const minSustain = MIN_SUSTAIN_MS / 1000;

  const events: EnergyEvent[] = [];
  let runStart = -1;
  let peak = 0;
  const flush = (endIdx: number) => {
    if (runStart < 0) return;
    const start = runStart * win;
    const end = endIdx * win;
    if (end - start >= minSustain) events.push({ start, end, peak });
    runStart = -1;
    peak = 0;
  };

  for (let i = 0; i < vFrames.length; i++) {
    const v = vFrames[i]!;
    const f = fFrames[i] ?? v;
    const vocalDominant = f <= 1e-6 ? false : v / f >= VOCAL_RATIO;
    if (v >= threshold && vocalDominant) {
      if (runStart < 0) runStart = i;
      peak = Math.max(peak, v);
    } else {
      flush(i);
    }
  }
  flush(vFrames.length);

  return events
    .sort((a, b) => b.peak - a.peak)
    .slice(0, maxEvents)
    .sort((a, b) => a.start - b.start);
}

/* ------------------------------------------------------------------ */
/* Offline render — full isolation + 0% ducking                        */
/* ------------------------------------------------------------------ */

export type MixOptions = {
  dub: AudioBuffer;
  original: AudioBuffer;
  clips: OverlayClip[];
};

export type ScheduledClip = {
  clip: OverlayClip;
  piece: AudioBuffer;
  at: number;
  dur: number;
};

/**
 * Slice every clip first, then schedule using the REAL `audioBuffer.duration`
 * (never the raw timestamp span). Overlapping clips are pushed to start right
 * after the previous clip's dynamic end, so nothing is cut short.
 */
export function scheduleClips(original: AudioBuffer, clips: OverlayClip[]): ScheduledClip[] {
  const usable = dedupeClips(clips.filter((c) => c.enabled && clipDuration(c) > 0.01));
  const out: ScheduledClip[] = [];
  let cursor = 0;

  for (const clip of usable) {
    const piece = sliceBuffer(original, clip.start, clip.end);
    const dur = piece.duration; // dynamic buffer duration
    const at = Math.max(0, clip.placeAt, cursor);
    cursor = at + dur; // clipEndTime = clipStartTime + audioBuffer.duration
    out.push({ clip, piece, at, dur });
  }

  return out;
}

/**
 * Render dub + original non-verbal clips 100% client-side.
 * The dub is ramped to 0% gain (30ms exponential) under every active clip so
 * the original emotion is completely isolated — no double voices.
 */
export async function renderOverlayMix({
  dub,
  original,
  clips,
}: MixOptions): Promise<AudioBuffer> {
  const rate = Math.max(dub.sampleRate, original.sampleRate);
  const channels = Math.max(dub.numberOfChannels, original.numberOfChannels, 1);

  const scheduled = scheduleClips(original, clips);

  const ramp = RAMP_MS / 1000;
  const lead = DUCK_LEAD_MS / 1000;
  const post = DUCK_TAIL_MS / 1000;

  const tail = scheduled.reduce((m, s) => Math.max(m, s.at + s.dur), 0);
  const totalSec = Math.max(dub.duration, tail + post + ramp, 0.1);

  const off = new OfflineAudioContext(channels, Math.ceil(totalSec * rate), rate);

  const dubSrc = off.createBufferSource();
  dubSrc.buffer = dub;

  const dubVol = off.createGain();
  dubVol.gain.setValueAtTime(1, 0);

  for (const { at, dur } of scheduled) {
    const duckAt = Math.max(0, at - lead); // exactly 0% 10ms before overlay
    const releaseAt = at + dur + post; // hold 0% until 20ms after overlay

    dubVol.gain.setValueAtTime(1, Math.max(0, duckAt - ramp));
    dubVol.gain.exponentialRampToValueAtTime(DUCK_FLOOR, duckAt);
    dubVol.gain.setValueAtTime(DUCK_FLOOR, releaseAt);
    dubVol.gain.exponentialRampToValueAtTime(1, releaseAt + ramp); // 30ms back to 1.0
  }

  dubSrc.connect(dubVol).connect(off.destination);
  dubSrc.start(0);

  for (const { piece, at, dur } of scheduled) {
    const src = off.createBufferSource();
    src.buffer = piece;

    const g = off.createGain();
    const fade = Math.min(ramp, dur / 3);

    g.gain.setValueAtTime(DUCK_FLOOR, at);
    g.gain.exponentialRampToValueAtTime(1, at + fade);
    g.gain.setValueAtTime(1, at + Math.max(fade, dur - fade));

    src.connect(g).connect(off.destination);
    src.start(at);
  }

  const rendered = await off.startRendering();

  dubSrc.buffer = null;
  for (const s of scheduled) {
    (s as { piece: AudioBuffer | null }).piece = null;
  }

  return rendered;
}
