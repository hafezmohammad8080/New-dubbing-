/**
 * MODULE 4 — Duration alignment & pitch-preserved time-stretching (lip-sync).
 *
 * Non-destructive add-on: it REUSES the existing WSOLA engine in
 * ./timestretch.ts and only adds
 *   1. duration-ratio math (T_tts / T_original),
 *   2. native `preservesPitch` playback-rate alignment for <audio> elements,
 *   3. a SoundTouch.js (CDN, lazy) fallback for extreme stretch ratios,
 * so generated dub clips land exactly on the original dialogue timing without
 * chipmunk / slowed-down artefacts.
 */

import { clampRate, fitBufferToDuration } from "./timestretch";

/** Ratios outside this band sound artefacty with naive resampling/WSOLA. */
export const EXTREME_MIN = 0.7;
export const EXTREME_MAX = 1.5;

const SOUNDTOUCH_CDN = "https://cdn.jsdelivr.net/npm/soundtouchjs@0.1.30/dist/soundtouch.js";

/** speedRatio = T_tts / T_original ( >1 → TTS is too long, must speed up ). */
export function computeSpeedRatio(ttsSec: number, originalSec: number): number {
  if (!(ttsSec > 0) || !(originalSec > 0.05)) return 1;
  return ttsSec / originalSec;
}

export const isExtremeRatio = (ratio: number) => ratio > EXTREME_MAX || ratio < EXTREME_MIN;

/**
 * Pin a plain <audio> element to the target duration with pitch preserved.
 * Used for live/non-blocking preview where re-rendering a buffer is overkill.
 */
export function applyPitchPreservedRate(
  el: HTMLAudioElement | null | undefined,
  ratio: number,
): number {
  if (!el) return 1;
  const rate = clampRate(ratio, EXTREME_MIN, EXTREME_MAX);
  type PitchFlags = {
    preservesPitch?: boolean;
    webkitPreservesPitch?: boolean;
    mozPreservesPitch?: boolean;
  };
  const flags = el as HTMLAudioElement & PitchFlags;
  flags.preservesPitch = true;
  flags.webkitPreservesPitch = true;
  flags.mozPreservesPitch = true;
  el.playbackRate = rate;
  return rate;
}

/** True when the browser exposes any pitch-preservation flag. */
export function nativePitchPreservationSupported(): boolean {
  if (typeof document === "undefined") return false;
  const el = document.createElement("audio");
  return "preservesPitch" in el || "webkitPreservesPitch" in el || "mozPreservesPitch" in el;
}

type SoundTouchModule = {
  SoundTouch: new () => { tempo: number; pitch: number; rate: number };
  SimpleFilter: new (
    source: { extract: (target: Float32Array, frames: number, position: number) => number },
    pipe: unknown,
  ) => { extract: (target: Float32Array, frames: number) => number };
};

let soundTouchPromise: Promise<SoundTouchModule | null> | null = null;

/** Lazily pull SoundTouch.js from the CDN. Never throws — returns null. */
export async function loadSoundTouch(): Promise<SoundTouchModule | null> {
  if (typeof window === "undefined") return null;
  soundTouchPromise ??= (async () => {
    try {
      const mod = (await import(/* @vite-ignore */ SOUNDTOUCH_CDN)) as Partial<SoundTouchModule>;
      if (mod?.SoundTouch && mod?.SimpleFilter) return mod as SoundTouchModule;
    } catch (err) {
      console.warn("[duration-align] SoundTouch.js CDN load failed:", err);
    }
    return null;
  })();
  return soundTouchPromise;
}

/**
 * Time-stretch an AudioBuffer with SoundTouch.js (100% pitch lock).
 * Returns null when the library is unavailable so callers can fall back.
 */
export async function soundTouchStretch(
  buffer: AudioBuffer,
  ratio: number,
  makeBuffer: (channels: number, length: number, rate: number) => AudioBuffer,
): Promise<AudioBuffer | null> {
  const st = await loadSoundTouch();
  if (!st) return null;
  try {
    const channels = Math.min(2, buffer.numberOfChannels);
    const left = buffer.getChannelData(0);
    const right = channels > 1 ? buffer.getChannelData(1) : left;
    const frames = buffer.length;

    const source = {
      extract(target: Float32Array, numFrames: number, position: number) {
        let got = 0;
        for (let i = 0; i < numFrames; i++) {
          const idx = position + i;
          if (idx >= frames) break;
          target[i * 2] = left[idx] ?? 0;
          target[i * 2 + 1] = right[idx] ?? 0;
          got++;
        }
        return got;
      },
    };

    const pipe = new st.SoundTouch();
    pipe.tempo = ratio; // >1 shorter, <1 longer — pitch untouched
    pipe.pitch = 1;
    const filter = new st.SimpleFilter(source, pipe);

    const outFrames = Math.max(1, Math.ceil(frames / ratio) + 1024);
    const outL = new Float32Array(outFrames);
    const outR = new Float32Array(outFrames);
    const block = new Float32Array(8192 * 2);
    let written = 0;
    for (;;) {
      const got = filter.extract(block, 8192);
      if (got <= 0) break;
      for (let i = 0; i < got && written + i < outFrames; i++) {
        outL[written + i] = block[i * 2] ?? 0;
        outR[written + i] = block[i * 2 + 1] ?? 0;
      }
      written += got;
      if (written >= outFrames) break;
    }
    if (written < 16) return null;

    const out = makeBuffer(channels, written, buffer.sampleRate);
    out.copyToChannel(outL.subarray(0, written), 0);
    if (channels > 1) out.copyToChannel(outR.subarray(0, written), 1);
    return out;
  } catch (err) {
    console.warn("[duration-align] SoundTouch stretch failed:", err);
    return null;
  }
}

export type AlignResult = {
  buffer: AudioBuffer;
  speedRatio: number;
  engine: "none" | "wsola" | "soundtouch";
};

/**
 * Fit a decoded TTS clip into the ORIGINAL segment duration, pitch preserved.
 * Extreme ratios go through SoundTouch.js; everything else uses the existing
 * in-app WSOLA stretcher (no network needed).
 */
export async function alignClipToSegment(
  buffer: AudioBuffer,
  targetSec: number,
  makeBuffer: (channels: number, length: number, rate: number) => AudioBuffer,
): Promise<AlignResult> {
  const speedRatio = computeSpeedRatio(buffer.duration, targetSec);
  if (Math.abs(speedRatio - 1) < 0.02) return { buffer, speedRatio, engine: "none" };

  if (isExtremeRatio(speedRatio)) {
    const stretched = await soundTouchStretch(buffer, speedRatio, makeBuffer);
    if (stretched) return { buffer: stretched, speedRatio, engine: "soundtouch" };
  }

  return {
    buffer: fitBufferToDuration(buffer, targetSec, makeBuffer),
    speedRatio,
    engine: "wsola",
  };
}
