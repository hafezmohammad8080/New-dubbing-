/** Browser-side audio helpers: decoding, chunking and timeline mixing. */

import { alignClipToSegment } from "./duration-align";
import { chunkKey, clearSession, deleteChunk, getChunk, putChunk, releaseMemory } from "./chunk-store";

const ANALYSIS_RATE = 16000;
const OUTPUT_RATE = 24000;

function encodeWav(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);
  const str = (off: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i));
  };
  str(0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  str(8, "WAVEfmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  str(36, "data");
  view.setUint32(40, samples.length * 2, true);
  let off = 44;
  for (let i = 0; i < samples.length; i++, off += 2) {
    const s = Math.max(-1, Math.min(1, samples[i] ?? 0));
    view.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return new Blob([buffer], { type: "audio/wav" });
}

async function blobToBase64(blob: Blob): Promise<string> {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let binary = "";
  const step = 0x8000;
  for (let i = 0; i < buf.length; i += step) {
    binary += String.fromCharCode(...buf.subarray(i, i + step));
  }
  return btoa(binary);
}

/** Decode any audio/video file to mono PCM at 16 kHz for analysis. */
export async function decodeForAnalysis(file: File): Promise<{ pcm: Float32Array; duration: number }> {
  const ctx = new AudioContext();
  const decoded = await ctx.decodeAudioData(await file.arrayBuffer());
  await ctx.close();

  const length = Math.ceil(decoded.duration * ANALYSIS_RATE);
  const off = new OfflineAudioContext(1, length, ANALYSIS_RATE);
  const src = off.createBufferSource();
  src.buffer = decoded;
  src.connect(off.destination);
  src.start();
  const rendered = await off.startRendering();
  return { pcm: rendered.getChannelData(0).slice(), duration: decoded.duration };
}

export type Chunk = { index: number; offset: number; base64: string };

/**
 * Split the decoded audio into small pieces (default 45s) so hours-long files
 * can be analysed piece by piece. There is no file-size limit.
 */
export async function* chunkAudio(
  pcm: Float32Array,
  chunkSeconds = 45,
): AsyncGenerator<Chunk> {
  const size = chunkSeconds * ANALYSIS_RATE;
  const total = Math.ceil(pcm.length / size);
  for (let i = 0; i < total; i++) {
    const slice = pcm.subarray(i * size, Math.min((i + 1) * size, pcm.length));
    const wav = encodeWav(slice, ANALYSIS_RATE);
    yield { index: i, offset: i * chunkSeconds, base64: await blobToBase64(wav) };
  }
}

/* ------------------------------------------------------------------ *
 * MODULE 6: hybrid memory-safe chunking (File.slice + IndexedDB)
 * ------------------------------------------------------------------ */

/** Read the real duration without decoding the file into RAM. */
export function probeDuration(file: File): Promise<number> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const el = document.createElement("audio");
    const done = (d: number) => {
      URL.revokeObjectURL(url);
      resolve(Number.isFinite(d) && d > 0 ? d : 0);
    };
    el.preload = "metadata";
    el.onloadedmetadata = () => done(el.duration);
    el.onerror = () => done(0);
    el.src = url;
  });
}

type WavInfo = { dataOffset: number; dataLength: number; bytesPerSecond: number; header: ArrayBuffer };

/** Parse a WAV header from the first bytes only, so slices can be cut exactly. */
async function readWavInfo(file: File): Promise<WavInfo | null> {
  try {
    const head = new DataView(await file.slice(0, 4096).arrayBuffer());
    const tag = (off: number) =>
      String.fromCharCode(head.getUint8(off), head.getUint8(off + 1), head.getUint8(off + 2), head.getUint8(off + 3));
    if (tag(0) !== "RIFF" || tag(8) !== "WAVE") return null;
    let off = 12;
    let byteRate = 0;
    while (off + 8 <= head.byteLength) {
      const id = tag(off);
      const size = head.getUint32(off + 4, true);
      if (id === "fmt ") byteRate = head.getUint32(off + 8 + 8, true);
      if (id === "data") {
        if (!byteRate) return null;
        const header = await file.slice(0, off + 8).arrayBuffer();
        return {
          dataOffset: off + 8,
          dataLength: Math.min(size, file.size - (off + 8)),
          bytesPerSecond: byteRate,
          header,
        };
      }
      off += 8 + size + (size % 2);
    }
    return null;
  } catch {
    return null;
  }
}

function wavSlice(info: WavInfo, from: number, to: number): Blob {
  const view = new DataView(info.header.slice(0));
  // Patch RIFF + data sizes to match the slice length.
  const len = to - from;
  view.setUint32(4, info.header.byteLength - 8 + len, true);
  view.setUint32(info.header.byteLength - 4, len, true);
  return new Blob([view.buffer], { type: "audio/wav" });
}

/** Downmix + resample one decoded slice to the 16 kHz mono WAV the analyser wants. */
async function sliceToAnalysisWav(bytes: Blob): Promise<Blob | null> {
  const ctx = new AudioContext();
  try {
    const decoded = await ctx.decodeAudioData(await bytes.arrayBuffer());
    const off = new OfflineAudioContext(1, Math.ceil(decoded.duration * ANALYSIS_RATE), ANALYSIS_RATE);
    const src = off.createBufferSource();
    src.buffer = decoded;
    src.connect(off.destination);
    src.start();
    const rendered = await off.startRendering();
    return encodeWav(rendered.getChannelData(0).slice(), ANALYSIS_RATE);
  } catch {
    return null;
  } finally {
    await ctx.close().catch(() => {});
  }
}

export type HybridChunk = Chunk & { total: number; key: string };

/**
 * Sequential FIFO chunk stream for files of ANY length.
 *
 * For every 1-minute window: cut the bytes with File.slice() (no full-file
 * read), park the raw blob in IndexedDB, pull it back, convert to analysis
 * WAV, yield it, then DELETE the stored chunk and release all references
 * before touching the next one. Strictly one chunk in memory at a time —
 * never Promise.all.
 */
export async function* hybridChunks(
  file: File,
  chunkSeconds = 60,
  session = `s${Date.now()}`,
): AsyncGenerator<HybridChunk> {
  const duration = (await probeDuration(file)) || 0;
  const wav = await readWavInfo(file);
  const bytesPerSecond = wav?.bytesPerSecond ?? (duration > 0 ? file.size / duration : 0);

  // No usable duration/byte-rate (exotic container): fall back to the legacy
  // full-decode path, but still stream it out one chunk at a time.
  if (!duration || !bytesPerSecond) {
    const { pcm } = await decodeForAnalysis(file);
    const total = Math.max(1, Math.ceil(pcm.length / (chunkSeconds * ANALYSIS_RATE)));
    let i = 0;
    for await (const c of chunkAudio(pcm, chunkSeconds)) {
      yield { ...c, total, key: chunkKey(session, i++) };
      await releaseMemory();
    }
    return;
  }

  const total = Math.max(1, Math.ceil(duration / chunkSeconds));
  for (let i = 0; i < total; i++) {
    const from = Math.floor(i * chunkSeconds * bytesPerSecond);
    const to = Math.min(
      file.size,
      Math.floor(Math.min((i + 1) * chunkSeconds, duration) * bytesPerSecond),
    );
    if (to <= from) break;

    const key = chunkKey(session, i);
    let raw: Blob | null = wav
      ? new Blob([wavSlice(wav, wav.dataOffset + from, wav.dataOffset + to), file.slice(wav.dataOffset + from, wav.dataOffset + to)], { type: "audio/wav" })
      : file.slice(from, to, file.type || "audio/mpeg");

    // Offload the raw bytes out of the JS heap before decoding.
    await putChunk(key, raw);
    raw = null;

    const stored = await getChunk(key);
    let analysis = stored ? await sliceToAnalysisWav(stored) : null;

    // Mid-stream slices of some containers (mp4/m4a) are not self-describing:
    // retry once with a header-prefixed slice from the file start.
    if (!analysis && !wav && i > 0) {
      analysis = await sliceToAnalysisWav(
        new Blob([file.slice(0, Math.min(from, 64 * 1024)), file.slice(from, to)], {
          type: file.type || "audio/mpeg",
        }),
      );
    }

    if (analysis) {
      const base64 = await blobToBase64(analysis);
      yield { index: i, offset: i * chunkSeconds, base64, total, key };
    } else {
      console.warn(`[audio] chunk ${i + 1}/${total} could not be decoded — skipped`);
    }

    // GC step: drop the IndexedDB copy and every reference we still hold.
    await deleteChunk(key);
    analysis = null;
    await releaseMemory();
  }

  await clearSession(session);
}


export type PlacedClip = {
  start: number;
  audio: ArrayBuffer;
  /** Duration of the ORIGINAL line — the clip is time-stretched to fit it. */
  target?: number;
};

/**
 * Lay every generated dialogue clip on a single timeline at its exact second,
 * so the dub keeps the original timing. When a clip is longer or shorter than
 * the original line, it is time-stretched (pitch preserved) to fit.
 */
export async function mixTimeline(clips: PlacedClip[], duration: number): Promise<Blob> {
  const ctx = new AudioContext();
  const buffers: Array<{ start: number; buffer: AudioBuffer }> = [];
  for (const clip of clips) {
    try {
      let buffer = await ctx.decodeAudioData(clip.audio.slice(0));
      if (clip.target && clip.target > 0.05) {
        // MODULE 4: duration alignment — pitch-preserved stretch so the clip
        // lasts exactly as long as the original dialogue segment.
        const aligned = await alignClipToSegment(
          buffer,
          clip.target,
          (channels, length, sampleRate) =>
            new AudioBuffer({ numberOfChannels: channels, length, sampleRate }),
        );
        buffer = aligned.buffer;
        if (aligned.engine !== "none") {
          console.info(
            `[audio] clip @${clip.start.toFixed(2)}s ratio=${aligned.speedRatio.toFixed(2)} engine=${aligned.engine}`,
          );
        }
      }
      buffers.push({ start: clip.start, buffer });
    } catch {
      /* skip undecodable clip */
    }
  }

  await ctx.close();

  const totalSec = Math.max(
    duration,
    ...buffers.map((b) => b.start + b.buffer.duration),
    1,
  );
  const off = new OfflineAudioContext(1, Math.ceil(totalSec * OUTPUT_RATE), OUTPUT_RATE);
  for (const b of buffers) {
    const src = off.createBufferSource();
    src.buffer = b.buffer;
    const gain = off.createGain();
    gain.gain.value = 1;
    src.connect(gain).connect(off.destination);
    src.start(b.start);
  }
  const rendered = await off.startRendering();
  return encodeWav(rendered.getChannelData(0).slice(), OUTPUT_RATE);
}

export const fmtTime = (s: number) => {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  const ms = Math.round((s % 1) * 10);
  return `${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}.${ms}`;
};
