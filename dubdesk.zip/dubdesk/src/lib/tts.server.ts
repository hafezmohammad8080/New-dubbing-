import { resilientFetch, ttsQueue, HttpError } from "@/lib/net";

export type SpeakInput = {
  text: string;
  engineVoice: string;
  persona: string;
  emotion?: string | undefined;
  intensity?: number | undefined;
  lang: "bn" | "hi" | "ur";
  quality?: "fast" | "pro";
  neuralVoiceId?: string | undefined;
  ssml?: string | undefined;
  emotionMode?: string | undefined;
};

const LANG_NAME = { bn: "Bengali (Bangla)", hi: "Hindi", ur: "Urdu" } as const;

const EMOTION_DIRECTION: Record<string, string> = {
  Aggressive: "Prosody: louder (+6dB), lower pitch (-5%), faster (+10%) — hard and forceful.",
  Pleading: "Prosody: softer (-2dB), higher pitch (+10%), slower (-5%) — begging and fragile.",
  Storytelling: "Prosody: steady storytelling pace with \~280ms pauses at every punctuation mark.",
  Normal: "Prosody: natural baseline pace, roughly +5% of neutral speed.",
};

export function buildDirection(i: SpeakInput): string {
  const loud =
    (i.intensity ?? 1) >= 1.25
      ? "Raise your volume and push the energy — this line is loud and forceful."
      : (i.intensity ?? 1) <= 0.75
        ? "Drop your volume — this line is quiet, close, almost under your breath."
        : "Keep a natural conversational volume, with normal human rise and fall.";

  return [
    i.persona,
    `Speak in ${LANG_NAME[i.lang]} with a completely natural native accent.`,
    "Perform this as real spoken dialogue from a film — NOT as reading aloud, NOT as narration, NOT cartoonish.",
    i.emotion ? `Emotional state: ${i.emotion}. Let it colour every word.` : "",
    i.emotionMode ? (EMOTION_DIRECTION[i.emotionMode] ?? "") : "",
    loud,
    "Use human imperfection: micro-pauses, breaths, small hesitations, changing pace, stress on the meaningful words, and let sentence endings fall naturally instead of a flat robotic tone.",
    "Say only the dialogue line below, nothing else:",
  ]
    .filter(Boolean)
    .join(" ");
}

export type SynthResult = {
  audio: ArrayBuffer | null;
  source: "public" | "browser";
  mime: string;
  reason?: string;
};

function chunkForPublicTTS(text: string, max = 180): string[] {
  const parts = text.match(/[^।.!?\n]+[।.!?\n]*\s*/g) ?? [text];
  const out: string[] = [];
  let cur = "";
  for (const part of parts) {
    if (part.length > max) {
      if (cur.trim()) out.push(cur.trim());
      cur = "";
      for (let i = 0; i < part.length; i += max) out.push(part.slice(i, i + max));
      continue;
    }
    if (cur.length + part.length > max) {
      out.push(cur.trim());
      cur = "";
    }
    cur += part;
  }
  if (cur.trim()) out.push(cur.trim());
  return out.filter(Boolean);
}

async function synthesizePublic(input: SpeakInput): Promise<ArrayBuffer> {
  const pieces = chunkForPublicTTS(input.text);
  const buffers: Uint8Array[] = [];
  for (const piece of pieces) {
    const url =
      `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${input.lang}` +
      `&q=${encodeURIComponent(piece)}`;
    const res = await ttsQueue.add(() =>
      resilientFetch(
        url,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
          },
        },
        { label: "public-tts", retries: 2, baseDelayMs: 1000 },
      ),
    );
    buffers.push(new Uint8Array(await res.arrayBuffer()));
  }
  const total = buffers.reduce((n, b) => n + b.byteLength, 0);
  if (total < 128) throw new Error("Public TTS returned empty audio");
  const merged = new Uint8Array(total);
  let offset = 0;
  for (const b of buffers) {
    merged.set(b, offset);
    offset += b.byteLength;
  }
  return merged.buffer;
}

/**
 * Never-throw synthesis: free public endpoint → "browser" signal
 */
export async function synthesize(input: SpeakInput): Promise<SynthResult> {
  let reason: string | undefined;

  try {
    return {
      audio: await synthesizePublic(input),
      source: "public",
      mime: "audio/mpeg",
    };
  } catch (err) {
    reason = err instanceof Error ? err.message : "public tts error";
    console.warn("[tts] public fallback failed, deferring to browser:", reason);
    return {
      audio: null,
      source: "browser",
      mime: "application/json",
      reason,
    };
  }
}