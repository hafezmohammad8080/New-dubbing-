/**
 * MODULE 2 — Robust audio fallback engine (browser side).
 *
 * TTS now runs on client-side Microsoft Edge Neural TTS (WebSocket, no
 * backend). `window.speechSynthesis` is only a last-resort fallback when the
 * neural socket is unavailable.
 */

import {
  findFallbackVoice,
  type AgeGroup,
  type Gender,
  type SupportedLanguage,
} from "@/lib/dubbingLogicHelpers";
import { synthesizeWithEdgeTTS, edgeTtsSupported } from "@/lib/edge-tts-client";
import { languageFromCode, resolveNeuralVoice, type VoiceType } from "@/lib/neural-voices";

const BCP47: Record<string, string> = { bn: "bn-BD", hi: "hi-IN", ur: "ur-PK", en: "en-US" };

export function browserTTSAvailable(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

/** Neural TTS availability (preferred path). */
export function neuralTTSAvailable(): boolean {
  return edgeTtsSupported();
}

/**
 * MODULE 6 (#15): pick the closest native voice for the target profile.
 * Exact lang+gender match -> any voice of that language -> global default.
 */
function pickVoice(
  lang: string,
  profile?: { gender?: Gender | undefined; age?: AgeGroup | undefined },
): SpeechSynthesisVoice | undefined {
  const voices = window.speechSynthesis.getVoices();
  const exactLocale = voices.find((v) => v.lang?.toLowerCase() === lang.toLowerCase());
  if (exactLocale && !profile?.gender) return exactLocale;
  return (
    findFallbackVoice(voices, {
      language: (lang.slice(0, 2) as SupportedLanguage) ?? "bn",
      gender: profile?.gender ?? "Female",
      age: profile?.age ?? "Adult",
    }) ?? exactLocale
  );
}

let activeAudio: HTMLAudioElement | null = null;
let activeUrl: string | null = null;

function voiceTypeOf(gender?: Gender, age?: AgeGroup): VoiceType {
  if (age === "Child") return "Child";
  return gender === "Male" ? "Male" : "Female";
}

/**
 * Speak text with the exact Microsoft Neural Voice for the requested
 * language + speaker type. Falls back to the native engine, never rejects.
 */
export async function speakWithBrowser(
  text: string,
  opts: {
    lang?: string;
    rate?: number;
    pitch?: number;
    volume?: number;
    gender?: Gender;
    age?: AgeGroup;
  } = {},
): Promise<boolean> {
  if (!text.trim()) return false;

  if (edgeTtsSupported()) {
    try {
      const language = languageFromCode(opts.lang);
      const voice = resolveNeuralVoice(language, voiceTypeOf(opts.gender, opts.age));
      const ratePct = Math.round(((opts.rate ?? 1) - 1) * 100);
      const blob = await synthesizeWithEdgeTTS({
        text,
        voice,
        rate: `${ratePct >= 0 ? "+" : ""}${ratePct}%`,
      });
      stopBrowserSpeech();
      activeUrl = URL.createObjectURL(blob);
      const audio = new Audio(activeUrl);
      audio.volume = opts.volume ?? 1;
      activeAudio = audio;
      await audio.play();
      return await new Promise<boolean>((resolve) => {
        audio.onended = () => resolve(true);
        audio.onerror = () => resolve(false);
      });
    } catch (err) {
      console.warn("[tts] neural voice failed, using system voice:", err);
    }
  }

  if (!browserTTSAvailable()) return false;
  const lang = BCP47[opts.lang ?? "bn"] ?? opts.lang ?? "bn-BD";
  return new Promise((resolve) => {
    try {
      const synth = window.speechSynthesis;
      synth.cancel();
      const utter = new SpeechSynthesisUtterance(text);
      utter.lang = lang;
      utter.rate = opts.rate ?? 1;
      utter.pitch = opts.pitch ?? 1;
      utter.volume = opts.volume ?? 1;
      const voice = pickVoice(lang, { gender: opts.gender, age: opts.age });
      if (voice) utter.voice = voice;

      utter.onend = () => resolve(true);
      utter.onerror = () => resolve(false);
      synth.speak(utter);
      // Safety: some browsers never fire onend for long text.
      setTimeout(() => resolve(true), Math.min(60000, 400 * text.length + 4000));
    } catch {
      resolve(false);
    }
  });
}

export function stopBrowserSpeech(): void {
  if (activeAudio) {
    activeAudio.pause();
    activeAudio = null;
  }
  if (activeUrl) {
    URL.revokeObjectURL(activeUrl);
    activeUrl = null;
  }
  if (browserTTSAvailable()) window.speechSynthesis.cancel();
}


/* ------------------------------------------------------------------ *
 * STT — native browser speech recognition
 * ------------------------------------------------------------------ */

type RecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: SpeechRecognitionResultEventLike) => void) | null;
  onerror: ((e: unknown) => void) | null;
  onend: (() => void) | null;
};

type SpeechRecognitionResultEventLike = {
  resultIndex: number;
  results: ArrayLike<
    ArrayLike<{ transcript: string }> & { isFinal: boolean }
  >;
};

function recognitionCtor(): (new () => RecognitionLike) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => RecognitionLike;
    webkitSpeechRecognition?: new () => RecognitionLike;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function browserSTTAvailable(): boolean {
  return recognitionCtor() !== null;
}

export type BrowserSTTHandle = {
  stop: () => void;
  /** Resolves with the full transcript once recognition ends. */
  done: Promise<string>;
};

/**
 * Start native live speech recognition (`SpeechRecognition` /
 * `webkitSpeechRecognition`). Returns a handle even when unsupported —
 * in that case `done` resolves with an empty string instead of throwing.
 */
export function startBrowserSTT(opts: {
  lang?: string;
  onPartial?: (text: string) => void;
}): BrowserSTTHandle {
  const Ctor = recognitionCtor();
  if (!Ctor) {
    return { stop: () => {}, done: Promise.resolve("") };
  }

  const lang = BCP47[opts.lang ?? "bn"] ?? opts.lang ?? "bn-BD";
  const rec = new Ctor();
  rec.lang = lang;
  rec.continuous = true;
  rec.interimResults = true;

  let finalText = "";
  let settle: (t: string) => void = () => {};
  const done = new Promise<string>((resolve) => {
    settle = resolve;
  });

  rec.onresult = (event) => {
    let interim = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const result = event.results[i]!;
      const alt = result[0];
      if (!alt) continue;
      if (result.isFinal) finalText += `${alt.transcript} `;
      else interim += alt.transcript;
    }
    opts.onPartial?.((finalText + interim).trim());
  };
  rec.onerror = () => settle(finalText.trim());
  rec.onend = () => settle(finalText.trim());

  try {
    rec.start();
  } catch {
    settle("");
  }

  return {
    stop: () => {
      try {
        rec.stop();
      } catch {
        settle(finalText.trim());
      }
    },
    done,
  };
}

/**
 * Transcribe with the external/AI path first and gracefully degrade to the
 * browser's native engine (live mic) when that path has no key, is rate
 * limited or fails. Always resolves — never blocks the flow.
 */
export async function transcribeWithFallback(
  external: () => Promise<string>,
  opts: { lang?: string; allowMicFallback?: boolean; onPartial?: (t: string) => void } = {},
): Promise<{ text: string; source: "external" | "browser" | "none" }> {
  try {
    const text = await external();
    if (text.trim()) return { text: text.trim(), source: "external" };
  } catch (err) {
    console.warn("[stt] external transcription failed, falling back:", err);
  }

  if (opts.allowMicFallback && browserSTTAvailable()) {
    const handle = startBrowserSTT({
      ...(opts.lang ? { lang: opts.lang } : {}),
      ...(opts.onPartial ? { onPartial: opts.onPartial } : {}),
    });
    const text = await handle.done;
    if (text) return { text, source: "browser" };
  }

  return { text: "", source: "none" };
}
