/**
 * MODULE 6: IndexedDB scratch store for raw audio chunks.
 *
 * Long files (1–2h+) are sliced on demand and parked here instead of in RAM.
 * Every chunk is deleted the moment it has been processed, so peak browser
 * memory stays flat regardless of input length.
 */

const DB_NAME = "dubdesk-chunks";
const STORE = "chunks";

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB unavailable"));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB open failed"));
  });
  return dbPromise;
}

function tx<T>(mode: IDBTransactionMode, run: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const t = db.transaction(STORE, mode);
        const req = run(t.objectStore(STORE));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error ?? new Error("IndexedDB request failed"));
      }),
  );
}

/** In-memory fallback used only when IndexedDB is blocked (private mode, etc.). */
const memory = new Map<string, Blob>();
let idbBroken = false;

export const chunkKey = (session: string, index: number) => `${session}/${index}`;

export async function putChunk(key: string, blob: Blob): Promise<void> {
  if (idbBroken) {
    memory.set(key, blob);
    return;
  }
  try {
    await tx("readwrite", (s) => s.put(blob, key) as IDBRequest<IDBValidKey>);
  } catch (err) {
    console.warn("[chunk-store] IndexedDB unavailable, using memory fallback:", err);
    idbBroken = true;
    memory.set(key, blob);
  }
}

export async function getChunk(key: string): Promise<Blob | null> {
  if (idbBroken) return memory.get(key) ?? null;
  try {
    return ((await tx<Blob | undefined>("readonly", (s) => s.get(key))) as Blob) ?? null;
  } catch {
    return memory.get(key) ?? null;
  }
}

export async function deleteChunk(key: string): Promise<void> {
  memory.delete(key);
  if (idbBroken) return;
  try {
    await tx("readwrite", (s) => s.delete(key) as unknown as IDBRequest<undefined>);
  } catch {
    /* nothing to clean up */
  }
}

/** Drop every chunk of a session — called when a run ends or is aborted. */
export async function clearSession(session: string): Promise<void> {
  for (const key of [...memory.keys()]) {
    if (key.startsWith(`${session}/`)) memory.delete(key);
  }
  if (idbBroken) return;
  try {
    const keys = await tx<IDBValidKey[]>("readonly", (s) => s.getAllKeys());
    await Promise.all(
      keys
        .filter((k) => typeof k === "string" && k.startsWith(`${session}/`))
        .map((k) => deleteChunk(k as string)),
    );
  } catch {
    /* ignore */
  }
}

/** Best-effort GC nudge between chunks: yield the event loop so the JS heap can settle. */
export async function releaseMemory(urls: string[] = []): Promise<void> {
  for (const url of urls) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      /* ignore */
    }
  }
  const gc = (globalThis as { gc?: () => void }).gc;
  if (typeof gc === "function") {
    try {
      gc();
    } catch {
      /* ignore */
    }
  }
  await new Promise((r) => setTimeout(r, 0));
}
