import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/* ---------------- Subtitle (SRT) helpers ---------------- */

/**
 * Sanitize subtitle text: strips control chars, zero-width/broken font
 * artifacts and foreign-script noise, while preserving natural colloquial
 * Bengali (চলতি বাংলা), Latin text, digits and punctuation.
 */
export function cleanSubtitleText(text: string, lang: string): string {
  if (!text) return "";
  let out = String(text)
    // control chars + zero-width / BOM / bidi marks (break fonts on mobile)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
    .replace(/[\uFEFF\u200B\u200E\u200F\u202A-\u202E\u2060]/g, "")
    // replacement / tofu glyphs from broken encodings
    .replace(/[\uFFFD\uE000-\uF8FF]/g, "")
    // markdown/quote artifacts from model output
    .replace(/[*_`~]+/g, "")
    .replace(/\s*\n\s*/g, " ");

  if (lang === "bn") {
    // keep Bengali, Latin, digits, whitespace and common punctuation only
    out = out.replace(/[^\u0980-\u09FFA-Za-z0-9\s.,!?;:'"()\-–—…।৳]/g, "");
  } else if (lang === "en") {
    out = out.replace(/[^A-Za-z0-9\s.,!?;:'"()\-–—…$%&/]/g, "");
  }

  return out.replace(/\s{2,}/g, " ").trim();
}

/**
 * Convert a timestamp to strict SRT time (`HH:MM:SS,mmm`).
 * Accepts seconds (number or "2.4"), "MM:SS(.ms)", "HH:MM:SS(.ms)".
 */
export function parseToSRTTime(timeInput: string | number): string {
  let total = 0;

  if (typeof timeInput === "number" && Number.isFinite(timeInput)) {
    total = timeInput;
  } else {
    const raw = String(timeInput ?? "").trim().replace(",", ".");
    if (!raw) {
      total = 0;
    } else if (raw.includes(":")) {
      const parts = raw.split(":").map((p) => parseFloat(p) || 0);
      while (parts.length < 3) parts.unshift(0);
      const [h = 0, m = 0, s = 0] = parts.slice(-3);
      total = h * 3600 + m * 60 + s;
    } else {
      total = parseFloat(raw) || 0;
    }
  }

  if (!Number.isFinite(total) || total < 0) total = 0;

  const ms = Math.round(total * 1000);
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const milli = ms % 1000;
  const p = (n: number, w = 2) => String(n).padStart(w, "0");
  return `${p(h)}:${p(m)}:${p(s)},${p(milli, 3)}`;
}

/**
 * Build + download an .srt file from dubbing segments.
 * Each segment is one full dialogue block (no mid-sentence splitting).
 * `lang`: "bn" (dub text), "en" (source text), "both" (dual line subtitle).
 */
export function downloadSRT(segments: any[], lang: "bn" | "en" | "both" = "bn"): void {
  const list = Array.isArray(segments) ? segments : [];
  if (!list.length) return;

  const blocks: string[] = [];
  let index = 0;

  for (let i = 0; i < list.length; i++) {
    const seg = list[i] ?? {};
    const bn = cleanSubtitleText(seg.text ?? "", "bn");
    const en = cleanSubtitleText(seg.source ?? "", "en");

    let body = "";
    if (lang === "bn") body = bn || en;
    else if (lang === "en") body = en || bn;
    else body = [bn, en].filter(Boolean).join("\n");

    if (!body) continue;

    const startNum = Number(seg.start);
    const endNum = Number(seg.end);
    const start = Number.isFinite(startNum) ? startNum : seg.start;
    let end: string | number = Number.isFinite(endNum) ? endNum : seg.end;

    // guard against zero/negative-length blocks
    if (Number.isFinite(startNum) && (!Number.isFinite(endNum) || endNum <= startNum)) {
      end = startNum + 2;
    }

    index += 1;
    blocks.push(
      `${index}\n${parseToSRTTime(start)} --> ${parseToSRTTime(end)}\n${body}\n`,
    );
  }

  if (!blocks.length) return;

  // UTF-8 BOM so Bengali renders correctly in VLC / mobile players
  const content = "\uFEFF" + blocks.join("\n");
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = lang === "both" ? "subtitle_bn_en.srt" : `subtitle_${lang}.srt`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
