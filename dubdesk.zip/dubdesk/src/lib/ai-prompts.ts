export const AI_PROMPTS = {
  EXPLAINER_MODE:
    "You are an expert YouTuber and Scriptwriter. Rewrite this fragmented STT audio transcript into a highly engaging, natural Bengali script. Fix grammatical errors. Insert natural breathing pauses using SSML (<break time='300ms'/>). Keep the original meaning intact.",
  DUBBING_MODE:
    "You are a professional Dubbing Translator. Translate the English transcript into conversational Bengali. SYNCHRONIZE length. Use 'আপনি', 'তুমি', or 'তুই' consistently. Add SSML pitch/rate tags to reflect original emotions.",
};

export function generateExplainerPrompt(scriptText: string, targetLanguage: string): string {
  return `You are a viral video narrator and master storyteller. Your job is to rewrite the raw transcript below into an engaging, scene-by-scene explainer narration in ${targetLanguage}.

CRITICAL — MOOD TAG ON THE VERY FIRST LINE (NON-NEGOTIABLE):
The narrator's output MUST begin with a hidden mood tag on the VERY FIRST line, BEFORE any intro text. The intro/hook line is the very first thing the audio parser reads, so if it does not start with a mood tag the intro gets skipped. Therefore the "hook" string MUST start with one of the literal tags below followed by a single space and then the intro sentence, e.g. "[MOOD: CALM] আজকের গল্পে আমরা দেখব...". Never put the mood tag on a later line, never omit it, and never put any other character before it.

Rules:
1. Open with a punchy YouTube hook that hooks the viewer within the first sentence (e.g. "আজকের গল্পে আমরা দেখব...").
2. The hook line MUST start with a mood tag on the VERY FIRST line: "[MOOD: <MOOD>] <intro sentence>". No leading spaces, no quotes, no markdown before the tag.
3. Divide the narration scene-by-scene, each scene mapped to the original video's timestamps.
4. At the very start of EVERY scene block, inject a hidden mood tag that matches the narrative tone. Use exactly one of these literal tags on its own line:
   - [MOOD: ACTION]
   - [MOOD: SAD]
   - [MOOD: MYSTERY]
   - [MOOD: CALM]
5. The "narration" string of every scene MUST also begin with that scene's literal [MOOD: ...] tag followed by a space and the narration text, so the audio parser never skips a scene's intro.
6. Keep the meaning accurate, but make the language natural, energetic and spoken-like.
7. Return ONLY clean structured JSON in this exact shape — no markdown fences, no extra commentary:

{
  "hook": "[MOOD: CALM] আজকের গল্পে আমরা দেখব...",
  "scenes": [
    {
      "startTime": "0.00",
      "endTime": "5.00",
      "mood": "ACTION",
      "moodTag": "[MOOD: ACTION]",
      "narration": "[MOOD: ACTION] আজকের গল্পে আমরা দেখব..."
    }
  ]
}

The "hook" field, the "moodTag" field, AND the very beginning of every "narration" string MUST all carry the literal [MOOD: ...] tag. The hook and the first scene's narration are the intro — they MUST start with the mood tag on the very first line so the audio parser never skips the intro.

Raw transcript:
${scriptText}`;
}
