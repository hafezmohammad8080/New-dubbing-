// Model Routing Engine (server-side core).
// Dynamic switching between "fast" (speed) and "slow" (accuracy) modes:
// the frontend's `mode` flag controls which model + temperature is used.

const GATEWAY = "https://ai.gateway.lovable.dev/v1";

export type ProcessingMode = "fast" | "slow";

export interface ModeConfig {
  modelName: string;
  temperature: number;
  description: string;
}

export const MODE_CONFIGS: Record<ProcessingMode, ModeConfig> = {
  fast: {
    modelName: "google/gemini-2.5-flash",
    temperature: 0.7,
    description: "High speed, optimized for quick storytelling drafts.",
  },
  slow: {
    modelName: "google/gemini-2.5-pro",
    temperature: 0.3,
    description: "High accuracy, optimized for deep reasoning, perfect translation, and precision.",
  },
};

export function resolveMode(raw: unknown): ProcessingMode {
  return raw === "slow" ? "slow" : "fast";
}

export function getGatewayKey(): string {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) throw new Error("Missing LOVABLE_API_KEY");
  return key;
}

export interface ChatMessage {
  role: "system" | "user";
  content: string;
}

/** Single chat completion against the Lovable AI Gateway. Throws on failure. */
export async function chatComplete(opts: {
  model: string;
  messages: ChatMessage[];
  temperature: number;
  jsonMode?: boolean;
}): Promise<string> {
  const res = await fetch(`${GATEWAY}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getGatewayKey()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: opts.model,
      temperature: opts.temperature,
      ...(opts.jsonMode ? { response_format: { type: "json_object" } } : {}),
      messages: opts.messages,
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`AI gateway error [${res.status}]: ${body.slice(0, 300)}`);
  }

  const json = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const text = json.choices?.[0]?.message?.content;
  if (!text?.trim()) throw new Error("Model returned no text");
  return text;
}

export interface RouteGenerateInput {
  mode?: unknown;
  prompt?: unknown;
  systemInstruction?: unknown;
}

export interface RouteGenerateResult {
  status: "success" | "error";
  mode_used?: ProcessingMode;
  model_used?: string;
  generated_text?: string;
  error_message?: string;
}

/** Core of POST /api/generate: routes the request to Flash or Pro by mode. */
export async function routeGenerate(payload: RouteGenerateInput): Promise<RouteGenerateResult> {
  const mode = resolveMode(payload.mode);
  const userPrompt = typeof payload.prompt === "string" ? payload.prompt : "";
  const systemInstruction =
    typeof payload.systemInstruction === "string" && payload.systemInstruction.trim()
      ? payload.systemInstruction
      : "You are an expert AI assistant.";

  if (!userPrompt.trim()) {
    return { status: "error", error_message: "Empty prompt" };
  }

  const config = MODE_CONFIGS[mode];

  try {
    const text = await chatComplete({
      model: config.modelName,
      temperature: config.temperature,
      messages: [
        { role: "system", content: systemInstruction },
        { role: "user", content: userPrompt },
      ],
    });

    return {
      status: "success",
      mode_used: mode,
      model_used: config.modelName,
      generated_text: text,
    };
  } catch (err) {
    return {
      status: "error",
      error_message: err instanceof Error ? err.message : "Unknown error",
    };
  }
}
