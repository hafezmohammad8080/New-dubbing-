import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const GATEWAY = "https://ai.gateway.lovable.dev/v1";

export const SegmentSchema = z.object({
  start: z.number(),
  end: z.number(),
  speaker: z.string(),
  category: z.enum([
    "adult_male",
    "adult_female",
    "elderly_male",
    "elderly_female",
    "young_boy",
    "young_girl",
    "teen_boy",
    "teen_girl",
  ]),
  source: z.string(),
  text: z.string(),
  emotion: z.string(),
  intensity: z.number().min(0.4).max(1.6),
});
export type Segment = z.infer<typeof SegmentSchema>;

/** A human non-verbal emotional sound kept from the original recording. */
export const NonVerbalSchema = z.object({
  start: z.number(),
  end: z.number(),
  kind: z.string().min(1).max(40),
});
export type NonVerbal = z.infer<typeof NonVerbalSchema>;

const Input = z.object({
  audioBase64: z.string().min(16),
  mime: z.string().default("wav"),
  offset: z.number().default(0),
  lang: z.enum(["bn", "hi", "ur"]),
});

const LANG_NAME = { bn: "Bengali (Bangla)", hi: "Hindi", ur: "Urdu" } as const;

const prompt = (lang: "bn" | "hi" | "ur") => `You are a dubbing script engineer.
Listen to the attached audio chunk and produce a second-by-second dubbing script.

For EVERY spoken utterance return one entry with:
- "start" and "end": seconds from the START OF THIS CHUNK, with 0.1s precision. Never overlap or guess — follow the audio exactly.
- "speaker": a stable label per distinct voice ("SPK1", "SPK2", ...).
- "category": the speaker's age+gender bucket, judged from timbre. One of
  adult_male (23-45), adult_female (23-45), elderly_male (45+), elderly_female (45+),
  young_boy (<12), young_girl (<12), teen_boy (13-22), teen_girl (13-22).
- "source": the original words, transcribed verbatim.
- "text": a natural, colloquial ${LANG_NAME[lang]} dub of that line — spoken register, not literary. Keep it short enough to fit the same duration.
- "emotion": how it is delivered, e.g. "angry", "sad, holding back tears", "teasing and laughing", "calm", "excited", "whispering, scared".
- "intensity": 0.4 (whisper) to 1.6 (shouting), 1.0 = normal.

ALSO return a "nonverbal" array for every human non-verbal emotional sound in the
audio (laughter, crying, sobbing, screaming, gasping, sighing, shouting without words).
Each entry: {"start","end","kind"} with seconds from the START OF THIS CHUNK and a short
kind label. These will be kept from the ORIGINAL recording, so be precise with the edges.

Ignore music and silence. Respond ONLY with JSON: {"segments":[...],"nonverbal":[...]}.`;

export const analyzeChunk = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    // Keys are optional: a missing key or a failing call must not halt the
    // dubbing pipeline — it degrades to an empty analysis for this chunk.
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      console.warn("[dub] LOVABLE_API_KEY missing — skipping AI analysis for this chunk");
      return { segments: [] as Segment[], nonverbal: [] as NonVerbal[] };
    }

    const res = await fetch(`${GATEWAY}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        response_format: { type: "json_object" },
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: prompt(data.lang) },
              {
                type: "input_audio",
                input_audio: { data: data.audioBase64, format: data.mime },
              },
            ],
          },
        ],
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      console.warn(`[dub] Analysis failed [${res.status}]: ${body}`);
      return { segments: [] as Segment[], nonverbal: [] as NonVerbal[] };
    }

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const raw = json.choices?.[0]?.message?.content ?? "{}";
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = {};
    }
    const list = (parsed as { segments?: unknown[] }).segments ?? [];
    const segments: Segment[] = [];
    for (const item of list) {
      const ok = SegmentSchema.safeParse(item);
      if (!ok.success) continue;
      segments.push({
        ...ok.data,
        start: ok.data.start + data.offset,
        end: Math.max(ok.data.end + data.offset, ok.data.start + data.offset + 0.3),
      });
    }

    const nvList = (parsed as { nonverbal?: unknown[] }).nonverbal ?? [];
    const nonverbal: NonVerbal[] = [];
    for (const item of nvList) {
      const ok = NonVerbalSchema.safeParse(item);
      if (!ok.success) continue;
      nonverbal.push({
        kind: ok.data.kind,
        start: ok.data.start + data.offset,
        end: Math.max(ok.data.end + data.offset, ok.data.start + data.offset + 0.2),
      });
    }

    return { segments, nonverbal };
  });
