/**
 * Direct client-side Microsoft Edge Neural TTS over WebSocket.
 *
 * No backend server is involved: the browser opens the same WSS endpoint the
 * Edge "Read aloud" feature uses, streams SSML up and collects the MP3 frames
 * back. Output is a raw MP3 Blob that any <audio> element can play.
 */

const TRUSTED_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
const ENDPOINT =
  "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1";
const SEC_MS_GEC_VERSION = "1-130.0.2849.68";
const OUTPUT_FORMAT = "audio-24khz-48kbitrate-mono-mp3";
const WIN_EPOCH_OFFSET_SEC = 11_644_473_600;

export type EdgeTtsRequest = {
  text: string;
  voice: string;
  /** Percent strings, e.g. "+10%" / "-5%". */
  rate?: string;
  volume?: string;
  /** Hz/percent string for prosody only — never used to fake age or gender. */
  pitch?: string;
  /** Pre-built SSML inner body; when set, `text` is ignored. */
  ssmlBody?: string;
  signal?: AbortSignal;
  timeoutMs?: number;
};

export class EdgeTtsError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "EdgeTtsError";
  }
}

export function edgeTtsSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof WebSocket !== "undefined" &&
    typeof crypto !== "undefined" &&
    !!crypto.subtle
  );
}

function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/** Microsoft's DRM token: SHA-256 of the 5-minute-rounded Windows ticks + trusted token. */
async function secMsGec(): Promise<string> {
  let ticks = Math.floor((Date.now() / 1000 + WIN_EPOCH_OFFSET_SEC) * 1e7);
  ticks -= ticks % 3_000_000_000; // round down to the nearest 5 minutes
  const data = new TextEncoder().encode(`${ticks}${TRUSTED_TOKEN}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

function connectId(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function buildSsml(req: EdgeTtsRequest): string {
  const lang = req.voice.split("-").slice(0, 2).join("-") || "en-US";
  const inner =
    req.ssmlBody ??
    `<prosody pitch="${req.pitch ?? "+0Hz"}" rate="${req.rate ?? "+0%"}" volume="${
      req.volume ?? "+0%"
    }">${escapeXml(req.text)}</prosody>`;
  return (
    `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${lang}">` +
    `<voice name="${req.voice}">${inner}</voice></speak>`
  );
}

/** Extract the binary audio payload that follows the message header. */
function audioPayload(buffer: ArrayBuffer): Uint8Array | null {
  const view = new DataView(buffer);
  if (buffer.byteLength < 2) return null;
  const headerLength = view.getUint16(0, false);
  if (buffer.byteLength <= headerLength + 2) return null;
  const header = new TextDecoder().decode(new Uint8Array(buffer, 2, headerLength));
  if (!/Path:\s*audio/i.test(header)) return null;
  return new Uint8Array(buffer, headerLength + 2);
}

/**
 * Same-origin fallback: browsers can't set the Origin/User-Agent headers the
 * Microsoft endpoint demands, so when the direct socket is rejected we ask our
 * own /api/edge-tts route to run the identical handshake. Still the very same
 * explicit Neural Voice ID — no pitch shifting anywhere.
 */
export async function synthesizeViaProxy(req: EdgeTtsRequest): Promise<Blob> {
  const res = await fetch("/api/edge-tts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      text: req.text,
      voice: req.voice,
      ...(req.rate ? { rate: req.rate } : {}),
      ...(req.volume ? { volume: req.volume } : {}),
      ...(req.pitch ? { pitch: req.pitch } : {}),
    }),
    ...(req.signal ? { signal: req.signal } : {}),
  });
  if (!res.ok) throw new EdgeTtsError(`Neural voice proxy failed (${res.status})`);
  const type = res.headers.get("Content-Type") ?? "";
  if (!type.startsWith("audio/")) {
    let reason = "Neural voice unavailable";
    try {
      const info = (await res.json()) as { reason?: string };
      if (info?.reason) reason = info.reason;
    } catch {
      /* ignore */
    }
    throw new EdgeTtsError(reason);
  }
  const blob = await res.blob();
  if (!blob.size) throw new EdgeTtsError("Neural voice proxy returned no audio");
  return blob;
}

/**
 * Synthesize one utterance. Resolves with an MP3 Blob, rejects with
 * `EdgeTtsError` so callers can fall back gracefully.
 */
export async function synthesizeWithEdgeTTS(req: EdgeTtsRequest): Promise<Blob> {
  if (!edgeTtsSupported()) return synthesizeViaProxy(req);
  try {
    return await synthesizeDirect(req);
  } catch (err) {
    if (req.signal?.aborted) throw err;
    return synthesizeViaProxy(req);
  }
}

async function synthesizeDirect(req: EdgeTtsRequest): Promise<Blob> {
  const text = (req.ssmlBody ?? req.text ?? "").trim();
  if (!text) throw new EdgeTtsError("Empty text");

  const gec = await secHash();

  const url =
    `${ENDPOINT}?TrustedClientToken=${TRUSTED_TOKEN}` +
    `&Sec-MS-GEC=${gec}&Sec-MS-GEC-Version=${SEC_MS_GEC_VERSION}` +
    `&ConnectionId=${connectId()}`;

  return new Promise<Blob>((resolve, reject) => {

    let ws: WebSocket;
    try {
      ws = new WebSocket(url);
    } catch (err) {
      reject(new EdgeTtsError(`Could not open TTS socket: ${String(err)}`));
      return;
    }
    ws.binaryType = "arraybuffer";

    const chunks: Uint8Array[] = [];
    let settled = false;

    const cleanup = () => {
      clearTimeout(timer);
      req.signal?.removeEventListener("abort", onAbort);
      try {
        if (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING) ws.close();
      } catch {
        /* ignore */
      }
    };
    const fail = (message: string) => {
      if (settled) return;
      settled = true;
      cleanup();
      reject(new EdgeTtsError(message));
    };
    const succeed = () => {
      if (settled) return;
      settled = true;
      cleanup();
      if (!chunks.length) {
        reject(new EdgeTtsError("No audio returned"));
        return;
      }
      resolve(new Blob(chunks as BlobPart[], { type: "audio/mpeg" }));
    };

    const timer = setTimeout(() => fail("TTS request timed out"), req.timeoutMs ?? 20000);
    const onAbort = () => fail("aborted");
    req.signal?.addEventListener("abort", onAbort);

    ws.onopen = () => {
      const stamp = new Date().toISOString();
      ws.send(
        `X-Timestamp:${stamp}\r\nContent-Type:application/json; charset=utf-8\r\n` +
          `Path:speech.config\r\n\r\n` +
          JSON.stringify({
            context: {
              synthesis: {
                audio: {
                  metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false },
                  outputFormat: OUTPUT_FORMAT,
                },
              },
            },
          }),
      );
      ws.send(
        `X-RequestId:${connectId()}\r\nContent-Type:application/ssml+xml\r\n` +
          `X-Timestamp:${stamp}Z\r\nPath:ssml\r\n\r\n${buildSsml(req)}`,
      );
    };

    ws.onmessage = (event: MessageEvent) => {
      if (typeof event.data === "string") {
        if (/Path:\s*turn\.end/i.test(event.data)) succeed();
        return;
      }
      const payload = audioPayload(event.data as ArrayBuffer);
      if (payload) chunks.push(payload);
    };

    ws.onerror = () => fail("TTS socket error");
    ws.onclose = () => (chunks.length ? succeed() : fail("TTS socket closed before audio"));
  });
}

async function secHash(): Promise<string> {
  return secMsGec();
}
