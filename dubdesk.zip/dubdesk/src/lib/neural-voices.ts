/**
 * MODULE 6b — Explicit Microsoft Edge Neural voice catalog.
 *
 * STRICT: every entry is a real Microsoft Neural Voice ID. No pitch-shifting
 * or audio manipulation is ever used to fake a gender or an age — the age /
 * gender difference comes from the neural voice itself.
 */

export type TtsLanguage = "bn" | "hi" | "ur" | "en";
export type VoiceType = "Female" | "Male" | "Child";

export type NeuralVoice = {
  id: string;
  label: string;
  type: VoiceType;
};

export const TTS_LANGUAGES: { value: TtsLanguage; label: string; locale: string }[] = [
  { value: "bn", label: "বাংলা (Bengali)", locale: "bn-BD" },
  { value: "hi", label: "हिन्दी (Hindi)", locale: "hi-IN" },
  { value: "ur", label: "اردو (Urdu)", locale: "ur-PK" },
  { value: "en", label: "English (US)", locale: "en-US" },
];

export const VOICE_TYPES: { value: VoiceType; label: string }[] = [
  { value: "Female", label: "Female" },
  { value: "Male", label: "Male" },
  { value: "Child", label: "Child / Young" },
];

/**
 * Explicit language -> voice-type -> Neural Voice ID map.
 * Languages without a dedicated child voice fall back to the closest
 * *real* neural voice for that locale (never a pitched-up adult voice).
 */
export const NEURAL_VOICES: Record<TtsLanguage, Partial<Record<VoiceType, NeuralVoice>>> = {
  bn: {
    Female: { id: "bn-BD-NabanitaNeural", label: "Nabanita (bn-BD)", type: "Female" },
    Male: { id: "bn-BD-PradeepNeural", label: "Pradeep (bn-BD)", type: "Male" },
    // No official bn-BD child neural voice — bn-IN Tanishaa is the real
    // youngest-sounding neural voice available for Bengali.
    Child: { id: "bn-IN-TanishaaNeural", label: "Tanishaa (bn-IN, young)", type: "Child" },
  },
  hi: {
    Female: { id: "hi-IN-SwaraNeural", label: "Swara (hi-IN)", type: "Female" },
    Male: { id: "hi-IN-MadhurNeural", label: "Madhur (hi-IN)", type: "Male" },
    Child: { id: "hi-IN-KavyanjaliNeural", label: "Kavyanjali (hi-IN, young)", type: "Child" },
  },
  ur: {
    Female: { id: "ur-PK-UzmaNeural", label: "Uzma (ur-PK)", type: "Female" },
    Male: { id: "ur-PK-AsadNeural", label: "Asad (ur-PK)", type: "Male" },
    // No child neural voice exists for ur-PK; use the real female voice.
    Child: { id: "ur-PK-UzmaNeural", label: "Uzma (ur-PK)", type: "Child" },
  },
  en: {
    Female: { id: "en-US-AvaNeural", label: "Ava (en-US)", type: "Female" },
    Male: { id: "en-US-AndrewNeural", label: "Andrew (en-US)", type: "Male" },
    Child: { id: "en-US-AnaNeural", label: "Ana (en-US, child)", type: "Child" },
  },
};

export function resolveNeuralVoice(language: TtsLanguage, type: VoiceType): string {
  const perLang = NEURAL_VOICES[language] ?? NEURAL_VOICES.en;
  return (perLang[type] ?? perLang.Female ?? NEURAL_VOICES.en.Female!).id;
}

export function localeOf(language: TtsLanguage): string {
  return TTS_LANGUAGES.find((l) => l.value === language)?.locale ?? "en-US";
}

export function languageFromCode(code?: string | null): TtsLanguage {
  const c = (code ?? "").slice(0, 2).toLowerCase();
  return c === "bn" || c === "hi" || c === "ur" || c === "en" ? c : "bn";
}
