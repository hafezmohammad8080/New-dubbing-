import { createFileRoute } from "@tanstack/react-router";
import { synthesize, type SpeakInput } from "@/lib/tts.server";
import { voiceById, LANGS } from "@/lib/voices";

export const Route = createFileRoute("/api/tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let payload: {
          voiceId: string;
          lang: SpeakInput["lang"];
          text?: string;
          emotion?: string;
          intensity?: number;
          quality?: "fast" | "pro";
          neuralVoiceId?: string;
          ssml?: string;
          emotionMode?: string;
        };
        try {
          payload = await request.json();
        } catch {
          return new Response("Invalid JSON body", { status: 400 });
        }

        const voice = voiceById(payload.voiceId);
        if (!voice) return new Response("Unknown voice", { status: 400 });
        const lang = (["bn", "hi", "ur"] as const).includes(payload.lang) ? payload.lang : "bn";
        const text =
          payload.text?.trim() || LANGS.find((l) => l.id === lang)!.sample;

        // MODULE 2: never hard-fail. synthesize() already degrades
        // gateway -> free public endpoint -> browser signal.
        try {
          const result = await synthesize({
            text,
            lang,
            engineVoice: voice.engineVoice,
            persona: voice.persona,
            emotion: payload.emotion,
            intensity: payload.intensity,
            quality: payload.quality ?? "fast",
            // MODULE 6 (#5 + #7): neural voice id + SSML from the client.
            neuralVoiceId: payload.neuralVoiceId,
            ssml: payload.ssml,
            emotionMode: payload.emotionMode,
          });


          if (!result.audio) {
            // 200 + JSON instruction: the client speaks it with Web Speech.
            return new Response(
              JSON.stringify({ fallback: "browser", text, lang, reason: result.reason ?? "" }),
              {
                status: 200,
                headers: {
                  "Content-Type": "application/json",
                  "X-TTS-Source": "browser",
                  "Cache-Control": "no-store",
                },
              },
            );
          }

          return new Response(result.audio, {
            headers: {
              "Content-Type": result.mime,
              "X-TTS-Source": result.source,
              "Cache-Control": "no-store",
            },
          });
        } catch (err) {
          const reason = err instanceof Error ? err.message : "TTS error";
          console.warn("[api/tts] unexpected failure, deferring to browser:", reason);
          return new Response(JSON.stringify({ fallback: "browser", text, lang, reason }), {
            status: 200,
            headers: {
              "Content-Type": "application/json",
              "X-TTS-Source": "browser",
              "Cache-Control": "no-store",
            },
          });
        }

      },
    },
  },
});
