import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

import Settings from "@/components/Settings";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Settings — DubDesk" },
      {
        name: "description",
        content:
          "Manage your Gemini and Groq API keys and choose the default AI model for DubDesk.",
      },
      { property: "og:title", content: "Settings — DubDesk" },
      {
        property: "og:description",
        content: "Manage API keys and the default AI model for DubDesk.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  return (
    <>
      <nav className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center gap-2 px-4 py-3">
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 rounded-lg border px-3 py-2 text-sm transition-colors hover:bg-secondary"
          >
            <ArrowLeft className="size-4" />
            Back
          </Link>
          <span className="ml-auto text-sm font-semibold gold-text">Settings</span>
        </div>
      </nav>

      <Settings />
    </>
  );
}
