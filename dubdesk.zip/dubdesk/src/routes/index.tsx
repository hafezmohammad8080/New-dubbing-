import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Settings as SettingsIcon } from "lucide-react";

import DubbingView from "@/components/DubbingView";
import ExplainerView from "@/components/ExplainerView";
import {
  BackgroundExecutionProvider,
  useBackgroundExecution,
} from "@/hooks/useBackgroundExecution";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "DubDesk — অডিও ডাবিং স্টুডিও: বাংলা, হিন্দি, উর্দু" },
      {
        name: "description",
        content:
          "যেকোনো দৈর্ঘ্যের অডিও আপলোড করুন — টাইমস্ট্যাম্পসহ ট্রান্সক্রিপ্ট, অনুবাদ ও বয়স-লিঙ্গ অনুযায়ী মানুষের মতো আবেগভরা ভয়েসে ডাবিং।",
      },
      { property: "og:title", content: "DubDesk — অডিও ডাবিং স্টুডিও" },
      {
        property: "og:description",
        content: "৮টি বয়স-লিঙ্গ ক্যাটাগরির ৩২টি ন্যাচারাল ভয়েসে বাংলা, হিন্দি ও উর্দু ডাবিং।",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=Hind+Siliguri:wght@400;500;600&display=swap",
      },
    ],
  }),
  component: DubDeskPage,
});


type TabId = "dubbing" | "explainer";

const TABS: { id: TabId; label: string }[] = [
  { id: "dubbing", label: "AI Dubbing" },
  { id: "explainer", label: "AI Explainer" },
];

function DubDeskPage() {
  const [tab, setTab] = useState<TabId>("dubbing");

  return (
    <BackgroundExecutionProvider>
      <nav className="sticky top-0 z-30 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex max-w-3xl items-center gap-2 px-4 py-3">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id)}
              className={`rounded-lg border px-4 py-2 text-sm transition-colors ${
                tab === t.id ? "gold-fill border-transparent font-semibold" : "hover:bg-secondary"
              }`}
            >
              {t.label}
            </button>
          ))}
          <Link
            to="/settings"
            aria-label="Open API settings"
            className="ml-auto inline-flex items-center justify-center rounded-lg border px-3 py-2 text-sm transition-colors hover:bg-secondary"
          >
            <SettingsIcon className="size-4" />
          </Link>
        </div>
      </nav>

      <div hidden={tab !== "dubbing"}>
        <DubbingView />
      </div>
      {tab === "explainer" && <ExplainerView />}
      <BackgroundBadge />
    </BackgroundExecutionProvider>
  );
}

/** Small live indicator shown while the background-execution lock is held. */
function BackgroundBadge() {
  const { active, wakeLock, beats } = useBackgroundExecution();
  if (!active) return null;
  return (
    <div className="fixed bottom-4 left-1/2 z-40 -translate-x-1/2 rounded-full border bg-background/90 px-4 py-2 text-xs shadow-lg backdrop-blur">
      ব্যাকগ্রাউন্ডে প্রসেসিং সচল · {wakeLock ? "স্ক্রিন লক প্রতিরোধ চালু" : "কিপ-অ্যালাইভ চালু"} · {beats}s
    </div>
  );
}
