/* DubDesk background keep-alive service worker.
 * Purpose: keep a live SW client + ping channel so the page's JS context is
 * less likely to be frozen/discarded while long dubbing jobs run with the
 * screen off. It intentionally does NOT cache or intercept app requests.
 */

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));

// Keeps the SW itself awake while a job is running: each ping extends the
// worker lifetime with a short waitUntil task.
self.addEventListener("message", (event) => {
  const type = event.data && event.data.type;
  if (type === "KEEPALIVE_PING") {
    event.waitUntil(
      new Promise((resolve) => {
        setTimeout(() => {
          if (event.source) event.source.postMessage({ type: "KEEPALIVE_PONG", at: Date.now() });
          resolve();
        }, 200);
      }),
    );
  }
});

// Answers the worker's own heartbeat request without touching the network.
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.pathname === "/__keepalive") {
    event.respondWith(new Response("ok", { headers: { "cache-control": "no-store" } }));
  }
});
